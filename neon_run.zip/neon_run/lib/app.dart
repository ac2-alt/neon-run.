import 'package:flutter/material.dart';

import 'core/audio.dart';
import 'core/l10n.dart';
import 'core/palette.dart';
import 'core/save.dart';
import 'ui/home_screen.dart';

/// Gives every screen access to save data and sound, and rebuilds them when
/// the save data changes (language, coins, missions, ...).
class AppScope extends InheritedNotifier<SaveData> {
  const AppScope({
    super.key,
    required SaveData save,
    required this.sfx,
    required super.child,
  }) : super(notifier: save);

  final Sfx sfx;

  static AppScope of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!;

  /// Like [of] but does not subscribe to changes (safe in initState).
  static AppScope read(BuildContext context) =>
      context.getInheritedWidgetOfExactType<AppScope>()!;

  SaveData get save => notifier!;
}

extension AppContext on BuildContext {
  SaveData get save => AppScope.of(this).save;
  Sfx get sfx => AppScope.of(this).sfx;
  String get lang => save.lang;
  String t(String key) => S.t(save.lang, key);
  String n(int value) => S.num(save.lang, value);
}

class NeonRunApp extends StatelessWidget {
  const NeonRunApp({super.key, required this.save, required this.sfx});

  final SaveData save;
  final Sfx sfx;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      save: save,
      sfx: sfx,
      child: _LifecycleGate(
        child: Builder(
          builder: (context) {
            final lang = AppScope.of(context).save.lang;
            return MaterialApp(
              title: 'NeonRun',
              debugShowCheckedModeBanner: false,
              theme: ThemeData(
                useMaterial3: true,
                brightness: Brightness.dark,
                scaffoldBackgroundColor: Palette.uiBg,
                colorScheme: const ColorScheme.dark(
                  primary: Color(0xFF00F0FF),
                  secondary: Color(0xFFFF2EC4),
                  surface: Palette.uiPanel,
                ),
              ),
              builder: (context, child) => Directionality(
                textDirection:
                    lang == 'fa' ? TextDirection.rtl : TextDirection.ltr,
                child: child ?? const SizedBox.shrink(),
              ),
              home: const HomeScreen(),
            );
          },
        ),
      ),
    );
  }
}

/// Pauses music when the app goes to the background and refreshes the daily
/// missions when it comes back (the day may have changed).
class _LifecycleGate extends StatefulWidget {
  const _LifecycleGate({required this.child});

  final Widget child;

  @override
  State<_LifecycleGate> createState() => _LifecycleGateState();
}

class _LifecycleGateState extends State<_LifecycleGate>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    if (scope == null) return;
    if (state == AppLifecycleState.resumed) {
      scope.sfx.resumeMusic();
      scope.save.refreshMissions();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      scope.sfx.pauseMusic();
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
