import 'dart:math' as math;

import 'entities.dart';
import 'world_gen.dart';

/// The whole game simulation. Pure Dart: feed it `update(dt)` and input calls,
/// read its state to draw. Deterministic for a given [math.Random].
class GameEngine {
  GameEngine({math.Random? random})
      : _rng = random ?? math.Random(),
        _gen = WorldGen(random ?? math.Random()) {
    _gen.fill(
      world: world,
      viewDistance: viewDistance,
      speed: speed,
      time: 0,
      traveled: 0,
    );
  }

  // ---- tuning ----
  static const double viewDistance = 140;
  static const double startSpeed = 17;
  static const double maxSpeed = 40;
  static const double jumpVelocity = 9.5;
  static const double gravity = 26;
  static const double standHeight = 1.0;
  static const double slideHeight = 0.5;
  static const double slideTime = 0.6;
  static const double magnetTime = 8;
  static const double doubleTime = 10;
  static const double invulnTime = 1.5;
  static const double inputBuffer = 0.14;

  final math.Random _rng;
  final WorldGen _gen;
  final World world = World();

  // ---- runner state ----
  int lane = 1;
  double x = 0;
  double y = 0;
  double vy = 0;
  double slideLeft = 0;

  // ---- run state ----
  bool alive = true;
  double time = 0;
  double traveled = 0;
  double score = 0;
  int coins = 0;
  int jumps = 0;
  int slides = 0;
  int powerups = 0;

  bool shield = false;
  double magnetLeft = 0;
  double doubleLeft = 0;
  double invuln = 0;

  double _jumpBuffer = 0;
  double _slideBuffer = 0;

  /// Events since the last [takeEvents] call (for sound, haptics, particles).
  final List<GameEvent> _events = [];

  double get speed => math.min(maxSpeed, startSpeed + time * 0.3);
  bool get grounded => y <= 0.0001 && vy <= 0;
  bool get sliding => slideLeft > 0;
  double get height => sliding ? slideHeight : standHeight;
  int get multiplier => doubleLeft > 0 ? 2 : 1;
  int get distance => traveled.floor();
  int get points => score.floor();

  List<GameEvent> takeEvents() {
    final out = List<GameEvent>.of(_events);
    _events.clear();
    return out;
  }

  // ---- input ----

  void moveLeft() => _changeLane(-1);
  void moveRight() => _changeLane(1);

  void _changeLane(int d) {
    if (!alive) return;
    final next = (lane + d).clamp(0, 2);
    if (next == lane) return;
    lane = next;
    _events.add(GameEvent.laneChange);
  }

  void jump() {
    if (!alive) return;
    if (grounded) {
      _doJump();
    } else {
      _jumpBuffer = inputBuffer;
    }
  }

  void slide() {
    if (!alive) return;
    if (grounded) {
      _doSlide();
    } else {
      // Dive: drop quickly and slide as soon as we land.
      vy = math.min(vy, -20);
      _slideBuffer = inputBuffer * 3;
    }
  }

  void _doJump() {
    vy = jumpVelocity;
    y = 0.001;
    slideLeft = 0;
    jumps++;
    _events.add(GameEvent.jump);
  }

  void _doSlide() {
    slideLeft = slideTime;
    slides++;
    _events.add(GameEvent.slide);
  }

  // ---- simulation ----

  void update(double rawDt) {
    if (!alive) return;
    final dt = rawDt.clamp(0.0, 0.05);
    if (dt == 0) return;

    time += dt;
    final dz = speed * dt;
    traveled += dz;
    score += dz * multiplier;

    // Horizontal lane smoothing.
    final target = (lane - 1).toDouble();
    x += (target - x) * math.min(1.0, dt * 16);
    if ((target - x).abs() < 0.001) x = target;

    // Vertical motion.
    if (!grounded) {
      vy -= gravity * dt;
      y += vy * dt;
      if (y <= 0) {
        y = 0;
        vy = 0;
        if (_jumpBuffer > 0) {
          _doJump();
        } else if (_slideBuffer > 0) {
          _doSlide();
        }
      }
    }
    if (slideLeft > 0) slideLeft = math.max(0, slideLeft - dt);
    _jumpBuffer = math.max(0, _jumpBuffer - dt);
    _slideBuffer = math.max(0, _slideBuffer - dt);

    // Timers.
    magnetLeft = math.max(0, magnetLeft - dt);
    doubleLeft = math.max(0, doubleLeft - dt);
    invuln = math.max(0, invuln - dt);

    // Scroll the world toward the runner.
    final obstaclePrev = <Obstacle, double>{
      for (final o in world.obstacles) o: o.z,
    };
    for (final o in world.obstacles) {
      o.z -= dz;
    }
    for (final c in world.coins) {
      c.z -= dz;
    }
    for (final p in world.powerUps) {
      p.z -= dz;
    }
    _gen.scroll(dz);

    _magnet(dt);
    _collectCoins();
    _collectPowerUps();
    _collideObstacles(obstaclePrev);
    _cleanup();

    _gen.fill(
      world: world,
      viewDistance: viewDistance,
      speed: speed,
      time: time,
      traveled: traveled,
    );
  }

  void _magnet(double dt) {
    if (magnetLeft <= 0) return;
    for (final c in world.coins) {
      if (c.z > 0 && c.z < 14) {
        final k = math.min(1.0, dt * 9);
        c.x += (x - c.x) * k;
        c.y += (y + 0.5 - c.y) * k;
        c.z -= speed * 0.5 * dt;
      }
    }
  }

  void _collectCoins() {
    world.coins.removeWhere((c) {
      if (c.z > 0.9 || c.z < -0.9) return false;
      if ((c.x - x).abs() > 0.6) return false;
      if (c.y > y + height + 0.5 || c.y < y - 0.5) return false;
      coins++;
      score += 10 * multiplier;
      _events.add(GameEvent.coin);
      return true;
    });
  }

  void _collectPowerUps() {
    world.powerUps.removeWhere((p) {
      if (p.z > 1.0 || p.z < -1.0) return false;
      if ((p.x - x).abs() > 0.6) return false;
      powerups++;
      switch (p.kind) {
        case PowerKind.shield:
          shield = true;
        case PowerKind.magnet:
          magnetLeft = magnetTime;
        case PowerKind.doubleScore:
          doubleLeft = doubleTime;
      }
      _events.add(GameEvent.powerup);
      return true;
    });
  }

  void _collideObstacles(Map<Obstacle, double> prev) {
    for (final o in world.obstacles) {
      if (o.broken) continue;
      final zPrev = prev[o] ?? o.z;
      // Swept test along z so a fast frame can never tunnel through.
      if (!(o.z < 0.8 && zPrev > -0.8)) continue;
      if ((o.x - x).abs() >= 0.68) continue;
      // Vertical overlap between runner [y, y+height] and obstacle.
      if (y >= o.top || y + height <= o.bottom) continue;
      if (invuln > 0) continue;
      if (shield) {
        shield = false;
        invuln = invulnTime;
        o.broken = true;
        _events.add(GameEvent.shieldBreak);
        continue;
      }
      alive = false;
      _events.add(GameEvent.crash);
      return;
    }
  }

  void _cleanup() {
    world.obstacles.removeWhere((o) => o.z < -4);
    world.coins.removeWhere((c) => c.z < -4);
    world.powerUps.removeWhere((p) => p.z < -4);
  }

  RunSummary get summary => RunSummary(
        score: points,
        coins: coins,
        distance: distance,
        jumps: jumps,
        slides: slides,
        powerups: powerups,
      );

  /// Exposed for tests that need to place their own objects.
  math.Random get random => _rng;
}

class RunSummary {
  const RunSummary({
    required this.score,
    required this.coins,
    required this.distance,
    required this.jumps,
    required this.slides,
    required this.powerups,
  });

  final int score;
  final int coins;
  final int distance;
  final int jumps;
  final int slides;
  final int powerups;
}
