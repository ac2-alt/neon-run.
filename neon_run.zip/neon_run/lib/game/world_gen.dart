import 'dart:math' as math;

import 'entities.dart';

enum _Pattern { coins, single, dbl, wallLow, wallHigh, mixed }

/// Procedural level generator.
///
/// Fairness rules that keep every row passable:
///  * a row never blocks all three lanes with walls (`block`);
///  * "wall" rows use only barriers that can be jumped (low) or slid under
///    (high), never both in the same row;
///  * consecutive rows with an open lane keep that lane within one step of the
///    previous one;
///  * the gap between rows grows with speed (always at least ~0.9 seconds).
class WorldGen {
  WorldGen(this._rng);

  final math.Random _rng;

  /// Distance ahead of the runner up to which the world has been generated.
  double head = 45;

  int _safeLane = 1;
  int _rows = 0;
  _Pattern? _last;
  double _nextPowerAt = 250;

  /// Moves the generation front toward the runner as the world scrolls.
  void scroll(double dz) => head -= dz;

  /// Generates rows until the world reaches [viewDistance].
  void fill({
    required World world,
    required double viewDistance,
    required double speed,
    required double time,
    required double traveled,
  }) {
    var guard = 0;
    while (head < viewDistance && guard++ < 20) {
      _row(world, speed, time, traveled);
    }
  }

  void _row(World w, double speed, double time, double traveled) {
    final d = math.min(1.0, time / 90.0);
    final z = head;
    final pattern = _pick(d);
    var used = 0.0;
    var powerLane = -1;

    switch (pattern) {
      case _Pattern.coins:
        final lane = _rng.nextInt(3);
        used = _coins(w, lane, z, 5 + _rng.nextInt(4));
        powerLane = lane;
      case _Pattern.single:
        final blocked = _rng.nextInt(3);
        w.obstacles.add(Obstacle(blocked, _kind(), z));
        if (_rng.nextDouble() < 0.5) {
          // Never put coins inside the obstacle's own lane.
          var coinLane = _openLane();
          if (coinLane == blocked) {
            coinLane = blocked == 1 ? (_rng.nextBool() ? 0 : 2) : 1;
          }
          used = _coins(w, coinLane, z - 2, 4);
        }
      case _Pattern.dbl:
        final open = _openLane();
        _safeLane = open;
        for (var l = 0; l < 3; l++) {
          if (l != open) w.obstacles.add(Obstacle(l, _kind(), z));
        }
        if (_rng.nextDouble() < 0.6) used = _coins(w, open, z - 3, 4);
        powerLane = open;
      case _Pattern.mixed:
        final open = _openLane();
        _safeLane = open;
        final others = <int>[0, 1, 2]..remove(open);
        others.shuffle(_rng);
        w.obstacles.add(Obstacle(others[0], ObstacleKind.block, z));
        w.obstacles.add(Obstacle(
          others[1],
          _rng.nextBool() ? ObstacleKind.low : ObstacleKind.high,
          z,
        ));
        if (_rng.nextDouble() < 0.6) used = _coins(w, open, z - 3, 4);
        powerLane = open;
      case _Pattern.wallLow:
        final sp = _jumpSpacing(speed);
        final wallZ = z + 3 * sp;
        for (var l = 0; l < 3; l++) {
          w.obstacles.add(Obstacle(l, ObstacleKind.low, wallZ));
        }
        // An arc of coins that rewards jumping at the right moment.
        for (var i = 0; i <= 6; i++) {
          final y = 0.5 + 1.0 * math.sin(math.pi * i / 6);
          w.coins.add(Coin(0, y, z + i * sp));
        }
        used = 6 * sp;
      case _Pattern.wallHigh:
        for (var l = 0; l < 3; l++) {
          w.obstacles.add(Obstacle(l, ObstacleKind.high, z));
        }
        for (var i = 0; i < 3; i++) {
          w.coins.add(Coin(0, 0.4, z - 1.8 + i * 1.8));
        }
    }

    if (powerLane >= 0 && traveled + z >= _nextPowerAt) {
      w.powerUps.add(PowerUp(_powerKind(), powerLane, z + 4));
      _nextPowerAt = traveled + z + 350 + _rng.nextDouble() * 300;
    }

    _last = pattern;
    _rows++;
    head = z + used + _gap(speed, d);
  }

  _Pattern _pick(double d) {
    if (_rows < 3) {
      return _rng.nextBool() ? _Pattern.coins : _Pattern.single;
    }
    final weights = <_Pattern, double>{
      _Pattern.coins: _last == _Pattern.coins ? 0.03 : 0.16,
      _Pattern.single: 0.26 - 0.10 * d,
      _Pattern.dbl: 0.14 + 0.12 * d,
      _Pattern.wallLow: 0.14,
      _Pattern.wallHigh: 0.12,
      _Pattern.mixed: 0.10 + 0.12 * d,
    };
    var total = 0.0;
    for (final v in weights.values) {
      total += v;
    }
    var r = _rng.nextDouble() * total;
    for (final e in weights.entries) {
      r -= e.value;
      if (r <= 0) return e.key;
    }
    return _Pattern.single;
  }

  ObstacleKind _kind() {
    final r = _rng.nextDouble();
    if (r < 0.4) return ObstacleKind.block;
    if (r < 0.7) return ObstacleKind.low;
    return ObstacleKind.high;
  }

  PowerKind _powerKind() {
    final r = _rng.nextDouble();
    if (r < 0.4) return PowerKind.shield;
    if (r < 0.7) return PowerKind.magnet;
    return PowerKind.doubleScore;
  }

  /// An open lane within one step of the previous open lane.
  int _openLane() {
    final lo = math.max(0, _safeLane - 1);
    final hi = math.min(2, _safeLane + 1);
    return lo + _rng.nextInt(hi - lo + 1);
  }

  /// Coin spacing that matches the length of one jump at the current speed.
  double _jumpSpacing(double speed) => math.max(1.5, speed * 0.64 / 6);

  double _gap(double speed, double d) {
    final base = math.max(15.0, speed * 0.9);
    return base + 2 + 6 * (1 - d) * _rng.nextDouble();
  }

  /// Adds a line of coins and returns the length it uses.
  double _coins(World w, int lane, double z, int count) {
    const spacing = 2.4;
    for (var i = 0; i < count; i++) {
      w.coins.add(Coin((lane - 1).toDouble(), 0.5, z + i * spacing));
    }
    return math.max(0.0, count * spacing - 3);
  }
}
