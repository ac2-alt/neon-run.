/// Pure Dart game entities. No Flutter imports, so the engine is unit-testable.
///
/// Coordinates: `z` is the distance ahead of the runner in meters (the runner
/// is at z = 0, objects move toward negative z). Lanes are 0, 1, 2 and the
/// horizontal position `x` is in lane units: -1 (left), 0 (middle), 1 (right).
library;

enum ObstacleKind {
  /// Low barrier: jump over it.
  low,

  /// Floating bar: slide under it.
  high,

  /// Full wall: change lane.
  block,
}

enum PowerKind { shield, magnet, doubleScore }

enum GameEvent { jump, slide, laneChange, coin, powerup, shieldBreak, crash }

class Obstacle {
  Obstacle(this.lane, this.kind, this.z);

  final int lane;
  final ObstacleKind kind;
  double z;
  bool broken = false;

  double get x => (lane - 1).toDouble();

  /// Vertical extent in meters above the ground.
  double get bottom => kind == ObstacleKind.high ? 0.75 : 0.0;

  double get top {
    switch (kind) {
      case ObstacleKind.low:
        return 0.65;
      case ObstacleKind.high:
        return 2.2;
      case ObstacleKind.block:
        return 2.4;
    }
  }
}

class Coin {
  Coin(this.x, this.y, this.z);

  double x;
  double y;
  double z;
}

class PowerUp {
  PowerUp(this.kind, this.lane, this.z);

  final PowerKind kind;
  final int lane;
  double z;

  double get x => (lane - 1).toDouble();
}

/// Everything currently alive in front of (and just behind) the runner.
class World {
  final List<Obstacle> obstacles = [];
  final List<Coin> coins = [];
  final List<PowerUp> powerUps = [];
}
