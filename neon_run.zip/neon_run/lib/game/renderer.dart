import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/palette.dart';
import 'engine.dart';
import 'entities.dart';

Color _a(Color c, double o) => c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// Visual-only state owned by the game screen (not part of the simulation).
class RenderState {
  /// Continuous clock for animation, keeps running while paused.
  double t = 0;

  /// 0..1 camera shake strength.
  double shake = 0;

  /// 0..1 white flash strength.
  double flash = 0;

  /// Seconds since the runner crashed (0 while alive).
  double deathTime = 0;
}

/// A short-lived spark in world space (x in meters, y up, z ahead).
class Particle {
  Particle({
    required this.x,
    required this.y,
    required this.z,
    required this.vx,
    required this.vy,
    required this.vz,
    required double life,
    required this.color,
    this.size = 0.12,
  })  : life = life,
        maxLife = life;

  double x, y, z, vx, vy, vz;
  double life;
  final double maxLife;
  final Color color;
  final double size;

  bool get dead => life <= 0;

  /// [scroll] is how far the world moved toward the runner this frame.
  void update(double dt, double scroll) {
    life -= dt;
    x += vx * dt;
    y += vy * dt;
    z += vz * dt - scroll;
    vy -= 9 * dt;
    if (y < 0) {
      y = 0;
      vy = -vy * 0.4;
    }
  }
}

/// Draws a neon runner. [feet] is the screen point under the runner and [u]
/// the number of pixels per meter at that depth.
void drawRunner(
  Canvas canvas, {
  required Offset feet,
  required double u,
  required Color color,
  bool sliding = false,
  bool airborne = false,
  double phase = 0,
  double alpha = 1,
}) {
  final glow = Paint()
    ..color = _a(color, 0.28 * alpha)
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..strokeWidth = 0.2 * u;
  final line = Paint()
    ..color = _a(color, alpha)
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..strokeWidth = 0.06 * u;
  final fill = Paint()
    ..color = _a(const Color(0xFF0B0B1A), alpha)
    ..style = PaintingStyle.fill;
  final visor = Paint()
    ..color = _a(Colors.white, alpha)
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round
    ..strokeWidth = 0.05 * u;

  if (sliding) {
    final body = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(feet.dx, feet.dy - 0.24 * u),
        width: 0.95 * u,
        height: 0.36 * u,
      ),
      Radius.circular(0.18 * u),
    );
    canvas.drawRRect(body, glow);
    canvas.drawRRect(body, fill);
    canvas.drawRRect(body, line);
    canvas.drawLine(
      Offset(feet.dx + 0.12 * u, feet.dy - 0.27 * u),
      Offset(feet.dx + 0.34 * u, feet.dy - 0.27 * u),
      visor,
    );
    return;
  }

  // Legs.
  final hip = Offset(feet.dx, feet.dy - 0.4 * u);
  Offset foot(double side) {
    if (airborne) {
      return Offset(feet.dx + side * 0.2 * u, feet.dy - 0.16 * u);
    }
    final s = math.sin(phase + (side > 0 ? 0 : math.pi));
    final lift = math.max(0.0, math.cos(phase + (side > 0 ? 0 : math.pi)));
    return Offset(feet.dx + s * 0.2 * u, feet.dy - lift * 0.14 * u);
  }

  for (final side in const [-1.0, 1.0]) {
    final f = foot(side);
    canvas.drawLine(hip, f, glow);
    canvas.drawLine(hip, f, line);
  }

  // Torso and head.
  final torso = RRect.fromRectAndRadius(
    Rect.fromCenter(
      center: Offset(feet.dx, feet.dy - 0.62 * u),
      width: 0.46 * u,
      height: 0.46 * u,
    ),
    Radius.circular(0.16 * u),
  );
  final headC = Offset(feet.dx, feet.dy - 0.9 * u);
  canvas.drawRRect(torso, glow);
  canvas.drawCircle(headC, 0.14 * u, glow);
  canvas.drawRRect(torso, fill);
  canvas.drawCircle(headC, 0.14 * u, fill);
  canvas.drawRRect(torso, line);
  canvas.drawCircle(headC, 0.14 * u, line);
  canvas.drawLine(
    Offset(headC.dx - 0.07 * u, headC.dy),
    Offset(headC.dx + 0.07 * u, headC.dy),
    visor,
  );
}

class _Item {
  _Item(this.z, this.draw);
  final double z;
  final void Function() draw;
}

/// Pseudo-3D renderer for the runner game.
class GamePainter extends CustomPainter {
  GamePainter({
    required this.engine,
    required this.rs,
    required this.particles,
    required this.theme,
    required this.skin,
    Listenable? repaint,
  }) : super(repaint: repaint);

  final GameEngine engine;
  final RenderState rs;
  final List<Particle> particles;
  final NeonTheme theme;
  final Color skin;

  /// Meters between lane centers.
  static const double laneM = 1.6;
  static const double _camD = 6;
  static const double _far = 150;

  static final List<double> _towers = () {
    final r = math.Random(7);
    return List<double>.generate(40, (_) => 0.2 + r.nextDouble() * 0.8);
  }();

  late double _w, _h, _cx, _horizon, _f, _camH, _camX, _u;

  Offset _p(double xm, double ym, double zm) {
    final d = math.max(0.5, zm + _camD);
    final s = _f / d;
    return Offset(_cx + (xm - _camX) * s, _horizon + (_camH - ym) * s);
  }

  double _scaleAt(double zm) => _f / math.max(0.5, zm + _camD);

  double _fog(double z) {
    if (z <= 55) return 1;
    return (1 - (z - 55) / 90).clamp(0.0, 1.0);
  }

  Path _poly(List<Offset> pts) {
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 1; i < pts.length; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    return path..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    _w = size.width;
    _h = size.height;
    _cx = _w / 2;
    _u = (_w * 0.30) / laneM;
    _f = _u * _camD;
    final feetY = _h * 0.8;
    _horizon = _h * 0.33;
    _camH = (feetY - _horizon) / _u;
    _camX = engine.x * laneM * 0.55;

    canvas.save();
    if (rs.shake > 0) {
      final r = math.Random((rs.t * 1000).floor());
      final amp = rs.shake * 10;
      canvas.translate(
        (r.nextDouble() - 0.5) * amp,
        (r.nextDouble() - 0.5) * amp,
      );
    }

    _sky(canvas);
    _ground(canvas);
    _road(canvas);
    _poles(canvas);
    _entities(canvas);
    _speedLines(canvas);
    canvas.restore();

    _vignette(canvas);
    if (rs.flash > 0) {
      canvas.drawRect(
        Rect.fromLTWH(0, 0, _w, _h),
        Paint()..color = _a(Colors.white, rs.flash * 0.55),
      );
    }
  }

  // ---------------------------------------------------------------- scenery

  void _sky(Canvas canvas) {
    final rect = Rect.fromLTWH(-20, -20, _w + 40, _horizon + 20);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.bgBottom, theme.bgTop],
        ).createShader(rect),
    );

    // Stars.
    final sr = math.Random(3);
    final star = Paint()..color = _a(Colors.white, 0.5);
    for (var i = 0; i < 26; i++) {
      final sx = sr.nextDouble() * _w;
      final sy = sr.nextDouble() * _horizon * 0.8;
      final tw = 0.5 + 0.5 * math.sin(rs.t * 2 + i);
      star.color = _a(Colors.white, 0.15 + 0.35 * tw);
      canvas.drawCircle(Offset(sx - _camX * 2, sy), 0.9 + sr.nextDouble(), star);
    }

    // Retro sun with stripes.
    final sunR = _w * 0.24;
    final sunC = Offset(_cx - _camX * 4, _horizon - sunR * 0.35);
    final sunRect = Rect.fromCircle(center: sunC, radius: sunR);
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, _w, _horizon));
    canvas.drawCircle(
      sunC,
      sunR,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [_a(theme.rail, 0.85), _a(theme.laneLine, 0.85)],
        ).createShader(sunRect),
    );
    final cut = Paint()..color = theme.bgTop;
    for (var i = 0; i < 6; i++) {
      final yy = sunC.dy + sunR * (0.05 + i * 0.16);
      final hh = 1.5 + i * 1.6;
      canvas.drawRect(Rect.fromLTWH(sunC.dx - sunR, yy, sunR * 2, hh), cut);
    }
    canvas.restore();

    // Skyline silhouettes.
    final baseY = _horizon;
    final bw = _w / 14;
    final off = -_camX * 6;
    final bPaint = Paint()..color = _a(theme.bgBottom, 1);
    final edge = Paint()
      ..color = _a(theme.rail, 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (var i = -2; i < 18; i++) {
      final hgt = _towers[(i + 40) % _towers.length] * _h * 0.09;
      final r = Rect.fromLTWH(i * bw + off, baseY - hgt, bw * 0.86, hgt);
      canvas.drawRect(r, bPaint);
      canvas.drawLine(r.topLeft, r.topRight, edge);
    }
  }

  void _ground(Canvas canvas) {
    final rect = Rect.fromLTWH(-20, _horizon, _w + 40, _h - _horizon + 20);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color.lerp(theme.bgTop, theme.bgBottom, 0.4)!,
            Color.lerp(theme.bgBottom, Colors.black, 0.45)!,
          ],
        ).createShader(rect),
    );
  }

  void _road(Canvas canvas) {
    const zn = -4.5;
    final edgeX = 1.5 * laneM;
    final road = _poly([
      _p(-edgeX, 0, zn),
      _p(edgeX, 0, zn),
      _p(edgeX, 0, _far),
      _p(-edgeX, 0, _far),
    ]);
    final roadRect = Rect.fromLTWH(0, _horizon, _w, _h - _horizon);
    canvas.drawPath(
      road,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _a(theme.bgTop, 0.95),
            Color.lerp(theme.bgBottom, Colors.black, 0.25)!,
          ],
        ).createShader(roadRect),
    );

    final scroll = engine.traveled;

    // Cross grid lines.
    const gridStep = 4.0;
    final gridOffset = scroll % gridStep;
    final gp = Paint()..style = PaintingStyle.stroke;
    for (var k = 0; k < 40; k++) {
      final z = k * gridStep - gridOffset;
      if (z < zn || z > _far) continue;
      final fog = _fog(z);
      gp
        ..color = _a(theme.rail, 0.22 * fog)
        ..strokeWidth = math.max(0.6, 0.03 * _scaleAt(z));
      canvas.drawLine(_p(-edgeX, 0, z), _p(edgeX, 0, z), gp);
    }

    // Lane dividers (dashed).
    const dash = 3.0, period = 6.0;
    final dOff = scroll % period;
    final dp = Paint()..style = PaintingStyle.fill;
    for (final lx in const [-0.5 * laneM, 0.5 * laneM]) {
      for (var k = 0; k < 28; k++) {
        final z0 = k * period - dOff;
        final z1 = z0 + dash;
        if (z1 < zn || z0 > _far) continue;
        final a0 = math.max(z0, zn);
        final fog = _fog(a0);
        dp.color = _a(theme.laneLine, 0.55 * fog);
        final hw = 0.045;
        canvas.drawPath(
          _poly([
            _p(lx - hw, 0, a0),
            _p(lx + hw, 0, a0),
            _p(lx + hw, 0, z1),
            _p(lx - hw, 0, z1),
          ]),
          dp,
        );
      }
    }

    // Glowing rails.
    for (final side in const [-1.0, 1.0]) {
      final x = side * edgeX;
      canvas.drawPath(
        _poly([
          _p(x - 0.28, 0, zn),
          _p(x + 0.28, 0, zn),
          _p(x + 0.28, 0, _far),
          _p(x - 0.28, 0, _far),
        ]),
        Paint()..color = _a(theme.rail, 0.18),
      );
      canvas.drawPath(
        _poly([
          _p(x - 0.07, 0, zn),
          _p(x + 0.07, 0, zn),
          _p(x + 0.07, 0, _far),
          _p(x - 0.07, 0, _far),
        ]),
        Paint()..color = _a(theme.rail, 0.95),
      );
    }
  }

  void _poles(Canvas canvas) {
    const step = 14.0;
    final off = engine.traveled % step;
    final pole = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final dot = Paint();
    for (var k = 0; k < 11; k++) {
      final z = k * step - off;
      if (z < -3 || z > _far) continue;
      final fog = _fog(z);
      final s = _scaleAt(z);
      for (final side in const [-1.0, 1.0]) {
        final x = side * (1.5 * laneM + 1.3);
        final base = _p(x, 0, z);
        final top = _p(x, 3.4, z);
        pole
          ..color = _a(theme.rail, 0.35 * fog)
          ..strokeWidth = math.max(1.0, 0.07 * s);
        canvas.drawLine(base, top, pole);
        dot.color = _a(theme.laneLine, 0.28 * fog);
        canvas.drawCircle(top, 0.34 * s, dot);
        dot.color = _a(Colors.white, 0.9 * fog);
        canvas.drawCircle(top, 0.1 * s, dot);
      }
    }
  }

  // --------------------------------------------------------------- entities

  void _entities(Canvas canvas) {
    final items = <_Item>[];
    final world = engine.world;

    for (final o in world.obstacles) {
      if (o.z > _far || o.z < -2.5) continue;
      items.add(_Item(o.z, () => _obstacle(canvas, o)));
    }
    for (final c in world.coins) {
      if (c.z > _far || c.z < -2.5) continue;
      items.add(_Item(c.z, () => _coin(canvas, c)));
    }
    for (final p in world.powerUps) {
      if (p.z > _far || p.z < -2.5) continue;
      items.add(_Item(p.z, () => _powerUp(canvas, p)));
    }
    for (final p in particles) {
      if (p.z > _far || p.z < -4) continue;
      items.add(_Item(p.z, () => _particle(canvas, p)));
    }
    if (engine.alive || rs.deathTime < 0.05) {
      items.add(_Item(0, () => _runner(canvas)));
    }

    // Far to near; the runner (z = 0) falls in between naturally.
    items.sort((a, b) => b.z.compareTo(a.z));
    for (final i in items) {
      i.draw();
    }
  }

  Color _obstacleColor(Obstacle o) {
    switch (o.kind) {
      case ObstacleKind.block:
        return theme.obstacle;
      case ObstacleKind.low:
        return const Color(0xFFFFA726);
      case ObstacleKind.high:
        return const Color(0xFFFF4D8D);
    }
  }

  void _obstacle(Canvas canvas, Obstacle o) {
    final color = _obstacleColor(o);
    final fog = _fog(o.z) * (o.z < -1 ? ((o.z + 2.5) / 1.5).clamp(0.0, 1.0) : 1);
    if (fog <= 0.01) return;
    final cx = o.x * laneM;
    final hw = laneM * 0.4;
    final zn = o.z - 0.5, zf = o.z + 0.5;
    final b = o.bottom, t = o.top;

    final fn = [
      _p(cx - hw, b, zn),
      _p(cx + hw, b, zn),
      _p(cx + hw, t, zn),
      _p(cx - hw, t, zn),
    ];
    final topFace = [
      _p(cx - hw, t, zn),
      _p(cx + hw, t, zn),
      _p(cx + hw, t, zf),
      _p(cx - hw, t, zf),
    ];

    final dark = Color.lerp(color, const Color(0xFF0B0B1A), 0.82)!;
    final mid = Color.lerp(color, const Color(0xFF0B0B1A), 0.6)!;
    final fillP = Paint()..style = PaintingStyle.fill;
    final edgeP = Paint()
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round
      ..color = _a(color, fog);
    final s = _scaleAt(o.z);
    edgeP.strokeWidth = math.max(1.2, 0.05 * s);
    final glowP = Paint()
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round
      ..color = _a(color, 0.22 * fog)
      ..strokeWidth = math.max(2.5, 0.2 * s);

    // Visible side face.
    final left = cx - hw;
    final right = cx + hw;
    List<Offset>? side;
    if (right < _camX) {
      side = [
        _p(right, b, zn),
        _p(right, b, zf),
        _p(right, t, zf),
        _p(right, t, zn),
      ];
    } else if (left > _camX) {
      side = [
        _p(left, b, zn),
        _p(left, b, zf),
        _p(left, t, zf),
        _p(left, t, zn),
      ];
    }
    if (side != null) {
      fillP.color = _a(dark, fog);
      canvas.drawPath(_poly(side), fillP);
    }
    fillP.color = _a(mid, fog);
    canvas.drawPath(_poly(topFace), fillP);

    final front = _poly(fn);
    final frontRect = Rect.fromPoints(fn[0], fn[2]);
    fillP
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [_a(mid, fog), _a(dark, fog)],
      ).createShader(frontRect)
      ..color = Colors.white;
    canvas.drawPath(front, fillP);
    fillP.shader = null;

    canvas.drawPath(front, glowP);

    // Warning stripes on barriers, inner frame on walls.
    canvas.save();
    canvas.clipPath(front);
    if (o.kind == ObstacleKind.block) {
      final inner = Paint()
        ..style = PaintingStyle.stroke
        ..color = _a(color, 0.45 * fog)
        ..strokeWidth = math.max(1.0, 0.03 * s);
      final inset = hw * 0.28;
      final ti = (t - b) * 0.14;
      canvas.drawPath(
        _poly([
          _p(cx - hw + inset, b + ti, zn),
          _p(cx + hw - inset, b + ti, zn),
          _p(cx + hw - inset, t - ti, zn),
          _p(cx - hw + inset, t - ti, zn),
        ]),
        inner,
      );
    } else {
      final stripe = Paint()
        ..style = PaintingStyle.stroke
        ..color = _a(color, 0.5 * fog)
        ..strokeWidth = math.max(1.0, 0.09 * s);
      final w = frontRect.width.abs();
      final hh = frontRect.height.abs();
      final left0 = math.min(fn[0].dx, fn[1].dx);
      final top0 = math.min(fn[0].dy, fn[2].dy);
      final gap = math.max(6.0, w / 5);
      for (var x = -hh; x < w + hh; x += gap) {
        canvas.drawLine(
          Offset(left0 + x, top0 + hh),
          Offset(left0 + x + hh, top0),
          stripe,
        );
      }
    }
    canvas.restore();

    canvas.drawPath(front, edgeP);
    canvas.drawPath(_poly(topFace), edgeP);
    if (side != null) canvas.drawPath(_poly(side), edgeP);
  }

  void _coin(Canvas canvas, Coin c) {
    final fog = _fog(c.z);
    if (fog <= 0.01) return;
    final ctr = _p(c.x * laneM, c.y, c.z);
    final s = _scaleAt(c.z);
    final r = 0.28 * s;
    final spin = math.cos(rs.t * 5 + c.z * 0.4).abs();
    final wRad = math.max(r * 0.18, r * spin);
    canvas.drawCircle(ctr, r * 1.7, Paint()..color = _a(Palette.coin, 0.16 * fog));
    final oval = Rect.fromCenter(center: ctr, width: wRad * 2, height: r * 2);
    canvas.drawOval(oval, Paint()..color = _a(Palette.coin, fog));
    if (wRad > r * 0.4) {
      canvas.drawOval(
        oval.deflate(r * 0.28),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(1.0, r * 0.14)
          ..color = _a(const Color(0xFFB8860B), fog),
      );
    }
  }

  Color _powerColor(PowerKind k) {
    switch (k) {
      case PowerKind.shield:
        return Palette.shield;
      case PowerKind.magnet:
        return Palette.magnet;
      case PowerKind.doubleScore:
        return Palette.doubleScore;
    }
  }

  void _powerUp(Canvas canvas, PowerUp p) {
    final fog = _fog(p.z);
    if (fog <= 0.01) return;
    final color = _powerColor(p.kind);
    final bob = 0.95 + 0.12 * math.sin(rs.t * 4);
    final ctr = _p(p.x * laneM, bob, p.z);
    final s = _scaleAt(p.z);
    final r = 0.46 * s;
    canvas.drawCircle(ctr, r * 1.8, Paint()..color = _a(color, 0.16 * fog));
    canvas.drawCircle(ctr, r, Paint()..color = _a(const Color(0xFF0B0B1A), fog));
    canvas.drawCircle(
      ctr,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.2, r * 0.16)
        ..color = _a(color, fog),
    );
    final g = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = math.max(1.2, r * 0.16)
      ..color = _a(color, fog);
    switch (p.kind) {
      case PowerKind.shield:
        final path = Path()
          ..moveTo(ctr.dx, ctr.dy - r * 0.55)
          ..lineTo(ctr.dx + r * 0.45, ctr.dy - r * 0.3)
          ..lineTo(ctr.dx + r * 0.38, ctr.dy + r * 0.15)
          ..quadraticBezierTo(
              ctr.dx + r * 0.25, ctr.dy + r * 0.5, ctr.dx, ctr.dy + r * 0.62)
          ..quadraticBezierTo(
              ctr.dx - r * 0.25, ctr.dy + r * 0.5, ctr.dx - r * 0.38, ctr.dy + r * 0.15)
          ..lineTo(ctr.dx - r * 0.45, ctr.dy - r * 0.3)
          ..close();
        canvas.drawPath(path, g);
      case PowerKind.magnet:
        final arc = Rect.fromCenter(
          center: Offset(ctr.dx, ctr.dy - r * 0.05),
          width: r * 0.9,
          height: r * 0.9,
        );
        canvas.drawArc(arc, math.pi, math.pi, false, g);
        canvas.drawLine(
          Offset(ctr.dx - r * 0.45, ctr.dy - r * 0.05),
          Offset(ctr.dx - r * 0.45, ctr.dy + r * 0.5),
          g,
        );
        canvas.drawLine(
          Offset(ctr.dx + r * 0.45, ctr.dy - r * 0.05),
          Offset(ctr.dx + r * 0.45, ctr.dy + r * 0.5),
          g,
        );
      case PowerKind.doubleScore:
        final tp = TextPainter(
          text: TextSpan(
            text: '2x',
            style: TextStyle(
              color: _a(color, fog),
              fontSize: math.max(6.0, r * 0.95),
              fontWeight: FontWeight.w900,
            ),
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, ctr - Offset(tp.width / 2, tp.height / 2));
    }
  }

  void _particle(Canvas canvas, Particle p) {
    final t = (p.life / p.maxLife).clamp(0.0, 1.0);
    final c = _p(p.x, p.y, p.z);
    final r = math.max(1.0, p.size * _scaleAt(p.z) * (0.4 + 0.6 * t));
    canvas.drawCircle(c, r * 2, Paint()..color = _a(p.color, 0.18 * t));
    canvas.drawCircle(c, r, Paint()..color = _a(p.color, t));
  }

  void _runner(Canvas canvas) {
    final x = engine.x * laneM;
    final feet = _p(x, engine.y, 0);
    final ground = _p(x, 0, 0);
    final u = _u;

    // Ground shadow.
    final sh = 1 / (1 + engine.y * 0.6);
    canvas.drawOval(
      Rect.fromCenter(center: ground, width: 0.8 * u * sh, height: 0.22 * u * sh),
      Paint()..color = _a(skin, 0.28 * sh),
    );

    var alpha = 1.0;
    if (engine.invuln > 0) {
      alpha = ((rs.t * 18).floor() % 2 == 0) ? 0.35 : 0.9;
    }

    // Magnet field.
    if (engine.magnetLeft > 0) {
      final pulse = (rs.t * 2) % 1;
      canvas.drawCircle(
        feet - Offset(0, 0.5 * u),
        (0.7 + pulse * 1.2) * u,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.04 * u
          ..color = _a(Palette.magnet, 0.5 * (1 - pulse)),
      );
    }

    drawRunner(
      canvas,
      feet: feet,
      u: u,
      color: skin,
      sliding: engine.sliding,
      airborne: !engine.grounded,
      phase: engine.traveled * 1.9,
      alpha: alpha,
    );

    if (engine.shield) {
      final c = feet - Offset(0, 0.55 * u);
      final pulse = 0.5 + 0.5 * math.sin(rs.t * 6);
      canvas.drawCircle(c, 0.82 * u, Paint()..color = _a(Palette.shield, 0.10 + 0.06 * pulse));
      canvas.drawCircle(
        c,
        0.82 * u,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.05 * u
          ..color = _a(Palette.shield, 0.7 + 0.3 * pulse),
      );
    }
  }

  // ---------------------------------------------------------------- overlay

  void _speedLines(Canvas canvas) {
    final k = ((engine.speed - GameEngine.startSpeed) /
            (GameEngine.maxSpeed - GameEngine.startSpeed))
        .clamp(0.0, 1.0);
    if (k <= 0.05 || !engine.alive) return;
    final p = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 1.5;
    final center = Offset(_cx, _horizon + 20);
    for (var i = 0; i < 16; i++) {
      final seed = i * 97.0;
      final ang = (seed % 360) * math.pi / 180;
      final ph = (rs.t * (1.4 + (i % 4) * 0.35) + seed) % 1;
      final r0 = _w * (0.35 + 0.8 * ph);
      final r1 = r0 + _w * 0.12 * (0.5 + k);
      final d = Offset(math.cos(ang), math.sin(ang).abs() * 0.5 + 0.5);
      p.color = _a(Colors.white, 0.12 * k * (1 - ph));
      canvas.drawLine(center + d * r0, center + d * r1, p);
    }
  }

  void _vignette(Canvas canvas) {
    final rect = Rect.fromLTWH(0, 0, _w, _h);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 1.1,
          colors: [Colors.transparent, _a(Colors.black, 0.55)],
          stops: const [0.6, 1.0],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant GamePainter oldDelegate) => true;
}
