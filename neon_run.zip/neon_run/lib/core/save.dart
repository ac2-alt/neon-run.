import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'missions.dart';

/// Totals from one finished run, used to update records and missions.
class RunStats {
  const RunStats({
    this.score = 0,
    this.coins = 0,
    this.distance = 0,
    this.jumps = 0,
    this.slides = 0,
    this.powerups = 0,
  });

  final int score;
  final int coins;
  final int distance;
  final int jumps;
  final int slides;
  final int powerups;
}

class MissionProgress {
  MissionProgress(this.id, {this.progress = 0, this.claimed = false});

  final String id;
  int progress;
  bool claimed;

  Map<String, dynamic> toJson() => {'id': id, 'p': progress, 'c': claimed};

  factory MissionProgress.fromJson(Map<String, dynamic> j) => MissionProgress(
        j['id'] as String,
        progress: (j['p'] as num?)?.toInt() ?? 0,
        claimed: j['c'] == true,
      );
}

/// All persistent player data. Lives on the device only.
class SaveData extends ChangeNotifier {
  SaveData._(this._prefs);

  final SharedPreferences _prefs;

  int best = 0;
  int coins = 0;
  int lifetimeCoins = 0;
  int runs = 0;
  int totalDistance = 0;
  Set<String> ownedSkins = {'white'};
  Set<String> ownedThemes = {'synth'};
  String skin = 'white';
  String theme = 'synth';
  bool sound = true;
  bool music = true;
  bool haptic = true;
  bool tutorialSeen = false;
  String lang = 'en';
  String missionDate = '';
  List<MissionProgress> missions = [];

  static Future<SaveData> load({DateTime? now}) async {
    final prefs = await SharedPreferences.getInstance();
    final s = SaveData._(prefs);
    s._read();
    s.refreshMissions(now: now, notify: false);
    return s;
  }

  void _read() {
    final p = _prefs;
    best = p.getInt('best') ?? 0;
    coins = p.getInt('coins') ?? 0;
    lifetimeCoins = p.getInt('lifetimeCoins') ?? 0;
    runs = p.getInt('runs') ?? 0;
    totalDistance = p.getInt('totalDistance') ?? 0;
    ownedSkins = {...(p.getStringList('skins') ?? const <String>[]), 'white'};
    ownedThemes = {...(p.getStringList('themes') ?? const <String>[]), 'synth'};
    skin = p.getString('skin') ?? 'white';
    theme = p.getString('theme') ?? 'synth';
    if (!ownedSkins.contains(skin)) skin = 'white';
    if (!ownedThemes.contains(theme)) theme = 'synth';
    sound = p.getBool('sound') ?? true;
    music = p.getBool('music') ?? true;
    haptic = p.getBool('haptic') ?? true;
    tutorialSeen = p.getBool('tutorialSeen') ?? false;
    final system = ui.PlatformDispatcher.instance.locale.languageCode;
    lang = p.getString('lang') ?? (system == 'fa' ? 'fa' : 'en');
    missionDate = p.getString('missionDate') ?? '';
    missions = [];
    try {
      final raw = jsonDecode(p.getString('missions') ?? '[]') as List<dynamic>;
      missions = raw
          .map((e) => MissionProgress.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      missions = [];
    }
  }

  void _save() {
    final p = _prefs;
    p.setInt('best', best);
    p.setInt('coins', coins);
    p.setInt('lifetimeCoins', lifetimeCoins);
    p.setInt('runs', runs);
    p.setInt('totalDistance', totalDistance);
    p.setStringList('skins', ownedSkins.toList());
    p.setStringList('themes', ownedThemes.toList());
    p.setString('skin', skin);
    p.setString('theme', theme);
    p.setBool('sound', sound);
    p.setBool('music', music);
    p.setBool('haptic', haptic);
    p.setBool('tutorialSeen', tutorialSeen);
    p.setString('lang', lang);
    p.setString('missionDate', missionDate);
    p.setString(
      'missions',
      jsonEncode(missions.map((m) => m.toJson()).toList()),
    );
  }

  void _commit() {
    _save();
    notifyListeners();
  }

  /// Creates today's missions if the day changed. Returns true if it did.
  bool refreshMissions({DateTime? now, bool notify = true}) {
    final date = now ?? DateTime.now();
    final key = MissionPool.dateKey(date);
    if (key == missionDate && missions.length == 3) return false;
    missionDate = key;
    missions =
        MissionPool.forDate(date).map((m) => MissionProgress(m.id)).toList();
    if (notify) {
      _commit();
    } else {
      _save();
    }
    return true;
  }

  /// Applies a finished run. Returns true when it set a new best score.
  bool recordRun(RunStats s, {DateTime? now}) {
    refreshMissions(now: now, notify: false);
    final newBest = s.score > best;
    if (newBest) best = s.score;
    coins += s.coins;
    lifetimeCoins += s.coins;
    runs += 1;
    totalDistance += s.distance;
    for (final mp in missions) {
      switch (MissionPool.byId(mp.id).kind) {
        case MissionKind.coins:
          mp.progress += s.coins;
        case MissionKind.distance:
          mp.progress += s.distance;
        case MissionKind.score:
          mp.progress = math.max(mp.progress, s.score);
        case MissionKind.jumps:
          mp.progress += s.jumps;
        case MissionKind.slides:
          mp.progress += s.slides;
        case MissionKind.powerups:
          mp.progress += s.powerups;
      }
    }
    _commit();
    return newBest;
  }

  /// Pays out a finished mission once. Returns true if coins were granted.
  bool claim(String id) {
    for (final mp in missions) {
      if (mp.id != id) continue;
      final def = MissionPool.byId(id);
      if (mp.claimed || mp.progress < def.target) return false;
      mp.claimed = true;
      coins += def.reward;
      _commit();
      return true;
    }
    return false;
  }

  bool buySkin(String id, int price) {
    if (ownedSkins.contains(id) || coins < price) return false;
    coins -= price;
    ownedSkins.add(id);
    skin = id;
    _commit();
    return true;
  }

  void equipSkin(String id) {
    if (!ownedSkins.contains(id)) return;
    skin = id;
    _commit();
  }

  bool buyTheme(String id, int price) {
    if (ownedThemes.contains(id) || coins < price) return false;
    coins -= price;
    ownedThemes.add(id);
    theme = id;
    _commit();
    return true;
  }

  void equipTheme(String id) {
    if (!ownedThemes.contains(id)) return;
    theme = id;
    _commit();
  }

  void setSound(bool v) {
    sound = v;
    _commit();
  }

  void setMusic(bool v) {
    music = v;
    _commit();
  }

  void setHaptic(bool v) {
    haptic = v;
    _commit();
  }

  void setLang(String v) {
    lang = v == 'fa' ? 'fa' : 'en';
    _commit();
  }

  void markTutorialSeen() {
    if (tutorialSeen) return;
    tutorialSeen = true;
    _commit();
  }

  Future<void> resetAll() async {
    await _prefs.clear();
    _read();
    refreshMissions(notify: false);
    notifyListeners();
  }
}
