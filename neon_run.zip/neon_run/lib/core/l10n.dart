import 'missions.dart';

/// Minimal Persian/English string table. No code generation needed.
class S {
  static const _fa = <String, String>{
    'app': 'نئون‌ران',
    'tagline': 'سریع‌تر از نور بدو',
    'play': 'شروع بازی',
    'shop': 'فروشگاه',
    'missions': 'ماموریت‌ها',
    'settings': 'تنظیمات',
    'best': 'رکورد',
    'coins': 'سکه',
    'score': 'امتیاز',
    'distance': 'مسافت',
    'meters': 'متر',
    'paused': 'توقف',
    'resume': 'ادامه',
    'restart': 'شروع دوباره',
    'home': 'خانه',
    'game_over': 'باختی!',
    'new_best': 'رکورد جدید!',
    'ready': 'آماده',
    'go': 'برو!',
    'tutorial_title': 'چطور بازی کنیم',
    'tut_swipe': 'کشیدن به چپ و راست: عوض کردن خط',
    'tut_up': 'کشیدن به بالا: پرش از روی مانع کوتاه',
    'tut_down': 'کشیدن به پایین: سُر خوردن زیر مانع بالایی',
    'tut_items': 'سکه جمع کن و آیتم‌ها را بگیر',
    'got_it': 'فهمیدم',
    'skins': 'رنگ دونده',
    'themes': 'تم‌ها',
    'buy': 'خرید',
    'owned': 'خریداری‌شده',
    'selected': 'انتخاب‌شده',
    'equip': 'انتخاب',
    'not_enough': 'سکه کافی نیست',
    'claim': 'دریافت',
    'claimed': 'دریافت شد',
    'daily_missions': 'ماموریت‌های امروز',
    'missions_hint': 'ماموریت‌ها هر روز عوض می‌شوند',
    'sound': 'افکت صوتی',
    'music': 'موسیقی',
    'vibration': 'لرزش',
    'language': 'زبان',
    'persian': 'فارسی',
    'english': 'English',
    'stats': 'آمار',
    'runs': 'تعداد بازی',
    'total_distance': 'کل مسافت',
    'lifetime_coins': 'کل سکه‌های جمع‌شده',
    'reset': 'پاک کردن اطلاعات',
    'reset_confirm': 'همه رکوردها، سکه‌ها و خریدها پاک می‌شود. مطمئنی؟',
    'cancel': 'انصراف',
    'confirm': 'تایید',
    'about': 'درباره',
    'about_text': 'رایگان، آفلاین و بدون تبلیغ. همه اطلاعات فقط روی گوشی تو می‌ماند.',
    'version': 'نسخه',
    'shield': 'سپر',
    'magnet': 'آهنربا',
    'double': 'امتیاز دو برابر',
    'm_coins': 'جمع‌آوری {n} سکه',
    'm_distance': 'دویدن {n} متر',
    'm_score': 'رسیدن به {n} امتیاز در یک بازی',
    'm_jumps': '{n} بار پریدن',
    'm_slides': '{n} بار سُر خوردن',
    'm_powerups': 'گرفتن {n} آیتم',
    'tap_to_resume': 'برای ادامه لمس کن',
  };

  static const _en = <String, String>{
    'app': 'NeonRun',
    'tagline': 'Run faster than light',
    'play': 'PLAY',
    'shop': 'Shop',
    'missions': 'Missions',
    'settings': 'Settings',
    'best': 'Best',
    'coins': 'Coins',
    'score': 'Score',
    'distance': 'Distance',
    'meters': 'm',
    'paused': 'Paused',
    'resume': 'Resume',
    'restart': 'Restart',
    'home': 'Home',
    'game_over': 'Game Over',
    'new_best': 'New best!',
    'ready': 'Ready',
    'go': 'Go!',
    'tutorial_title': 'How to play',
    'tut_swipe': 'Swipe left or right to change lane',
    'tut_up': 'Swipe up to jump over low barriers',
    'tut_down': 'Swipe down to slide under high barriers',
    'tut_items': 'Collect coins and grab power-ups',
    'got_it': 'Got it',
    'skins': 'Runner colors',
    'themes': 'Themes',
    'buy': 'Buy',
    'owned': 'Owned',
    'selected': 'Selected',
    'equip': 'Equip',
    'not_enough': 'Not enough coins',
    'claim': 'Claim',
    'claimed': 'Claimed',
    'daily_missions': "Today's missions",
    'missions_hint': 'Missions change every day',
    'sound': 'Sound effects',
    'music': 'Music',
    'vibration': 'Vibration',
    'language': 'Language',
    'persian': 'فارسی',
    'english': 'English',
    'stats': 'Stats',
    'runs': 'Runs played',
    'total_distance': 'Total distance',
    'lifetime_coins': 'Coins collected',
    'reset': 'Erase all data',
    'reset_confirm':
        'All records, coins and purchases will be erased. Are you sure?',
    'cancel': 'Cancel',
    'confirm': 'Confirm',
    'about': 'About',
    'about_text':
        'Free, offline and ad-free. All data stays on your phone.',
    'version': 'Version',
    'shield': 'Shield',
    'magnet': 'Magnet',
    'double': 'Double score',
    'm_coins': 'Collect {n} coins',
    'm_distance': 'Run {n} m',
    'm_score': 'Reach {n} points in one run',
    'm_jumps': 'Jump {n} times',
    'm_slides': 'Slide {n} times',
    'm_powerups': 'Pick up {n} power-ups',
    'tap_to_resume': 'Tap to resume',
  };

  static const _faDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

  /// Looks up a string, falling back to English and then to the key itself.
  static String t(String lang, String key) {
    final table = lang == 'fa' ? _fa : _en;
    return table[key] ?? _en[key] ?? key;
  }

  /// Formats an integer with thousands grouping and localized digits.
  static String num(String lang, int value) {
    final negative = value < 0;
    final raw = value.abs().toString();
    final buf = StringBuffer();
    for (var i = 0; i < raw.length; i++) {
      if (i > 0 && (raw.length - i) % 3 == 0) {
        buf.write(lang == 'fa' ? '٬' : ',');
      }
      buf.write(raw[i]);
    }
    var out = buf.toString();
    if (lang == 'fa') {
      out = out.split('').map((c) {
        final d = int.tryParse(c);
        return d == null ? c : _faDigits[d];
      }).join();
    }
    return negative ? '-$out' : out;
  }

  /// Human text for a mission, e.g. "Collect 50 coins".
  static String mission(String lang, MissionDef def) {
    final key = switch (def.kind) {
      MissionKind.coins => 'm_coins',
      MissionKind.distance => 'm_distance',
      MissionKind.score => 'm_score',
      MissionKind.jumps => 'm_jumps',
      MissionKind.slides => 'm_slides',
      MissionKind.powerups => 'm_powerups',
    };
    return t(lang, key).replaceAll('{n}', num(lang, def.target));
  }
}
