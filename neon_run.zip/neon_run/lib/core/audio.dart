import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

import 'save.dart';

/// Sound effects, music and haptics. Every call is failure-safe: if the audio
/// engine is unavailable (tests, unsupported device) the game keeps running.
class Sfx {
  Sfx(this._save);

  final SaveData _save;

  static const _names = [
    'jump',
    'coin',
    'slide',
    'crash',
    'powerup',
    'shield_break',
    'click',
    'mission',
  ];

  final Map<String, List<AudioPlayer>> _pools = {};
  final Map<String, int> _next = {};
  AudioPlayer? _music;
  bool _ready = false;
  bool _musicWanted = false;

  Future<void> init() async {
    if (_ready) return;
    try {
      for (final n in _names) {
        final pool = <AudioPlayer>[];
        for (var i = 0; i < 3; i++) {
          final p = AudioPlayer();
          await p.setPlayerMode(PlayerMode.lowLatency);
          await p.setReleaseMode(ReleaseMode.stop);
          await p.setVolume(0.8);
          pool.add(p);
        }
        _pools[n] = pool;
        _next[n] = 0;
      }
      final m = AudioPlayer();
      await m.setReleaseMode(ReleaseMode.loop);
      await m.setVolume(0.35);
      _music = m;
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  void play(String name) {
    if (!_save.sound || !_ready) return;
    try {
      final pool = _pools[name];
      if (pool == null) return;
      final i = _next[name] ?? 0;
      _next[name] = (i + 1) % pool.length;
      final p = pool[i];
      p.stop().catchError((_) {});
      p.play(AssetSource('audio/$name.wav')).catchError((_) {});
    } catch (_) {}
  }

  void startMusic() {
    _musicWanted = true;
    if (!_save.music || !_ready) return;
    try {
      _music?.play(AssetSource('audio/music.wav'));
    } catch (_) {}
  }

  void stopMusic() {
    _musicWanted = false;
    try {
      _music?.stop();
    } catch (_) {}
  }

  void pauseMusic() {
    try {
      _music?.pause();
    } catch (_) {}
  }

  void resumeMusic() {
    if (!_musicWanted || !_save.music || !_ready) return;
    try {
      _music?.resume();
    } catch (_) {}
  }

  /// Call after the music setting changed.
  void syncMusicSetting() {
    if (!_save.music) {
      pauseMusic();
    } else if (_musicWanted) {
      try {
        _music?.play(AssetSource('audio/music.wav'));
      } catch (_) {}
    }
  }

  void tap() {
    play('click');
    if (_save.haptic) HapticFeedback.selectionClick();
  }

  void buzz({bool heavy = false}) {
    if (!_save.haptic) return;
    if (heavy) {
      HapticFeedback.heavyImpact();
    } else {
      HapticFeedback.lightImpact();
    }
  }

  Future<void> dispose() async {
    try {
      for (final pool in _pools.values) {
        for (final p in pool) {
          await p.dispose();
        }
      }
      await _music?.dispose();
    } catch (_) {}
  }
}
