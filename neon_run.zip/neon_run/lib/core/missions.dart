import 'dart:math';

enum MissionKind { coins, distance, score, jumps, slides, powerups }

class MissionDef {
  const MissionDef(this.id, this.kind, this.target, this.reward);

  final String id;
  final MissionKind kind;
  final int target;
  final int reward;

  /// Score missions are judged on the best single run, the others accumulate.
  bool get isBestOfRun => kind == MissionKind.score;
}

class MissionPool {
  static const List<MissionDef> all = [
    MissionDef('c1', MissionKind.coins, 50, 40),
    MissionDef('c2', MissionKind.coins, 120, 90),
    MissionDef('d1', MissionKind.distance, 1000, 50),
    MissionDef('d2', MissionKind.distance, 2500, 120),
    MissionDef('s1', MissionKind.score, 2000, 60),
    MissionDef('s2', MissionKind.score, 5000, 150),
    MissionDef('j1', MissionKind.jumps, 25, 40),
    MissionDef('j2', MissionKind.jumps, 60, 90),
    MissionDef('l1', MissionKind.slides, 20, 40),
    MissionDef('l2', MissionKind.slides, 50, 90),
    MissionDef('p1', MissionKind.powerups, 3, 50),
    MissionDef('p2', MissionKind.powerups, 8, 110),
  ];

  static MissionDef byId(String id) =>
      all.firstWhere((m) => m.id == id, orElse: () => all.first);

  static String dateKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Picks three missions of different kinds, deterministic for a given day.
  static List<MissionDef> forDate(DateTime d) {
    final rng = Random(d.year * 10000 + d.month * 100 + d.day);
    final pool = List<MissionDef>.of(all)..shuffle(rng);
    final picked = <MissionDef>[];
    for (final m in pool) {
      if (picked.any((p) => p.kind == m.kind)) continue;
      picked.add(m);
      if (picked.length == 3) break;
    }
    return picked;
  }
}
