import 'package:flutter/material.dart';

/// A purchasable runner color.
class RunnerSkin {
  const RunnerSkin(this.id, this.color, this.price, this.nameFa, this.nameEn);

  final String id;
  final Color color;
  final int price;
  final String nameFa;
  final String nameEn;

  String name(String lang) => lang == 'fa' ? nameFa : nameEn;
}

/// A purchasable world theme (background, road and accent colors).
class NeonTheme {
  const NeonTheme({
    required this.id,
    required this.bgTop,
    required this.bgBottom,
    required this.rail,
    required this.laneLine,
    required this.obstacle,
    required this.price,
    required this.nameFa,
    required this.nameEn,
  });

  final String id;
  final Color bgTop;
  final Color bgBottom;
  final Color rail;
  final Color laneLine;
  final Color obstacle;
  final int price;
  final String nameFa;
  final String nameEn;

  String name(String lang) => lang == 'fa' ? nameFa : nameEn;
}

class Palette {
  static const Color coin = Color(0xFFFFD60A);
  static const Color shield = Color(0xFF3DDCFF);
  static const Color magnet = Color(0xFFFF4D6D);
  static const Color doubleScore = Color(0xFFB388FF);
  static const Color uiBg = Color(0xFF0B0B1A);
  static const Color uiPanel = Color(0xFF16162B);
  static const Color uiText = Color(0xFFEFF3FF);
  static const Color uiMuted = Color(0xFF8E94B8);

  static const List<RunnerSkin> skins = [
    RunnerSkin('white', Color(0xFFFFFFFF), 0, 'سفید', 'Pure White'),
    RunnerSkin('cyan', Color(0xFF00F0FF), 150, 'فیروزه‌ای', 'Cyan'),
    RunnerSkin('lime', Color(0xFFB6FF3B), 250, 'لیمویی', 'Lime'),
    RunnerSkin('amber', Color(0xFFFFB300), 400, 'کهربایی', 'Amber'),
    RunnerSkin('pink', Color(0xFFFF4FD8), 600, 'صورتی نئونی', 'Hot Pink'),
    RunnerSkin('violet', Color(0xFFB388FF), 900, 'بنفش', 'Violet'),
  ];

  static const List<NeonTheme> themes = [
    NeonTheme(
      id: 'synth',
      bgTop: Color(0xFF14083A),
      bgBottom: Color(0xFF0B0B1A),
      rail: Color(0xFF00F0FF),
      laneLine: Color(0xFFFF2EC4),
      obstacle: Color(0xFFFF2EC4),
      price: 0,
      nameFa: 'سینت‌ویو',
      nameEn: 'Synthwave',
    ),
    NeonTheme(
      id: 'matrix',
      bgTop: Color(0xFF021A0E),
      bgBottom: Color(0xFF020B07),
      rail: Color(0xFF39FF14),
      laneLine: Color(0xFF00B86B),
      obstacle: Color(0xFFFF5A36),
      price: 300,
      nameFa: 'ماتریکس',
      nameEn: 'Matrix',
    ),
    NeonTheme(
      id: 'sunset',
      bgTop: Color(0xFF3A0A2E),
      bgBottom: Color(0xFF12060F),
      rail: Color(0xFFFF9E00),
      laneLine: Color(0xFFFF4D6D),
      obstacle: Color(0xFF00E5FF),
      price: 500,
      nameFa: 'غروب',
      nameEn: 'Sunset',
    ),
    NeonTheme(
      id: 'ice',
      bgTop: Color(0xFF06223F),
      bgBottom: Color(0xFF040E1C),
      rail: Color(0xFF9BE7FF),
      laneLine: Color(0xFF5AA9FF),
      obstacle: Color(0xFFFF6B9D),
      price: 700,
      nameFa: 'یخ',
      nameEn: 'Ice',
    ),
  ];

  static RunnerSkin skin(String id) =>
      skins.firstWhere((s) => s.id == id, orElse: () => skins.first);

  static NeonTheme theme(String id) =>
      themes.firstWhere((t) => t.id == id, orElse: () => themes.first);
}
