import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app.dart';
import '../core/palette.dart';
import '../game/renderer.dart' show drawRunner;

const Color kCyan = Color(0xFF00F0FF);
const Color kPink = Color(0xFFFF2EC4);

Color withAlphaF(Color c, double o) =>
    c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// Text style that stays correct in Persian (no letter spacing, which would
/// break the joined letters) and can glow.
TextStyle neonStyle(
  BuildContext context, {
  double size = 16,
  Color color = Palette.uiText,
  FontWeight weight = FontWeight.w700,
  bool glow = false,
}) {
  return TextStyle(
    fontSize: size,
    color: color,
    fontWeight: weight,
    height: 1.25,
    letterSpacing: context.lang == 'fa' ? 0 : size * 0.05,
    shadows: glow
        ? [Shadow(color: withAlphaF(color, 0.8), blurRadius: size * 0.7)]
        : null,
  );
}

/// Animated synthwave backdrop used on the menu screens.
class NeonBackground extends StatefulWidget {
  const NeonBackground({super.key, required this.child});

  final Widget child;

  @override
  State<NeonBackground> createState() => _NeonBackgroundState();
}

class _NeonBackgroundState extends State<NeonBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Palette.theme(context.save.theme);
    return Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(
          child: CustomPaint(painter: _GridPainter(theme, _c)),
        ),
        widget.child,
      ],
    );
  }
}

class _GridPainter extends CustomPainter {
  _GridPainter(this.theme, this.anim) : super(repaint: anim);

  final NeonTheme theme;
  final Animation<double> anim;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.bgTop, theme.bgBottom],
        ).createShader(rect),
    );

    final horizon = h * 0.62;

    // Sun.
    final sunR = w * 0.3;
    final sunC = Offset(w / 2, horizon - sunR * 0.25);
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, w, horizon));
    canvas.drawCircle(
      sunC,
      sunR,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            withAlphaF(theme.rail, 0.55),
            withAlphaF(theme.laneLine, 0.55),
          ],
        ).createShader(Rect.fromCircle(center: sunC, radius: sunR)),
    );
    final cut = Paint()..color = theme.bgTop;
    for (var i = 0; i < 6; i++) {
      canvas.drawRect(
        Rect.fromLTWH(
          sunC.dx - sunR,
          sunC.dy + sunR * (0.05 + i * 0.16),
          sunR * 2,
          1.5 + i * 1.6,
        ),
        cut,
      );
    }
    canvas.restore();

    // Floor.
    final floor = Rect.fromLTWH(0, horizon, w, h - horizon);
    canvas.drawRect(floor, Paint()..color = theme.bgBottom);

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    // Converging verticals.
    for (var i = -10; i <= 10; i++) {
      final topX = w / 2 + i * w * 0.03;
      final botX = w / 2 + i * w * 0.30;
      line.color = withAlphaF(theme.laneLine, 0.35);
      canvas.drawLine(Offset(topX, horizon), Offset(botX, h), line);
    }
    // Moving horizontals.
    for (var i = 0; i < 10; i++) {
      final t = ((i + anim.value) / 10);
      final y = horizon + (h - horizon) * (t * t);
      line.color = withAlphaF(theme.rail, 0.15 + 0.4 * t);
      canvas.drawLine(Offset(0, y), Offset(w, y), line);
    }
    // Horizon glow.
    canvas.drawRect(
      Rect.fromLTWH(0, horizon - 1, w, 2),
      Paint()..color = withAlphaF(theme.rail, 0.9),
    );
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.theme != theme;
}

/// Standard screen: background, safe area, back button, title.
class ScreenFrame extends StatelessWidget {
  const ScreenFrame({
    super.key,
    required this.title,
    required this.child,
    this.trailing,
  });

  final String title;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: Container(
          color: withAlphaF(Palette.uiBg, 0.72),
          child: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 16, 8),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          context.sfx.tap();
                          Navigator.of(context).maybePop();
                        },
                        icon: const Icon(Icons.arrow_back_rounded),
                        color: Palette.uiText,
                        iconSize: 28,
                        tooltip: MaterialLocalizations.of(context)
                            .backButtonTooltip,
                      ),
                      Expanded(
                        child: Text(
                          title,
                          style: neonStyle(
                            context,
                            size: 24,
                            weight: FontWeight.w900,
                            color: kCyan,
                            glow: true,
                          ),
                        ),
                      ),
                      trailing ?? const SizedBox.shrink(),
                    ],
                  ),
                ),
                Expanded(child: child),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CoinIcon extends StatelessWidget {
  const CoinIcon({super.key, this.size = 20});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Palette.coin,
        border: Border.all(color: const Color(0xFFB8860B), width: size * 0.12),
        boxShadow: [
          BoxShadow(
            color: withAlphaF(Palette.coin, 0.55),
            blurRadius: size * 0.6,
          ),
        ],
      ),
    );
  }
}

class CoinChip extends StatelessWidget {
  const CoinChip({super.key, required this.value});

  final int value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: withAlphaF(Palette.uiPanel, 0.9),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: withAlphaF(Palette.coin, 0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CoinIcon(),
          const SizedBox(width: 8),
          Text(
            context.n(value),
            style: neonStyle(context, size: 16, color: Palette.coin),
          ),
        ],
      ),
    );
  }
}

/// Rounded neon button with a press animation and click sound.
class NeonButton extends StatefulWidget {
  const NeonButton({
    super.key,
    required this.label,
    required this.onTap,
    this.color = kCyan,
    this.icon,
    this.filled = true,
    this.height = 56,
    this.fontSize = 18,
  });

  final String label;
  final VoidCallback? onTap;
  final Color color;
  final IconData? icon;
  final bool filled;
  final double height;
  final double fontSize;

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final c = enabled ? widget.color : Palette.uiMuted;
    final fg = widget.filled ? const Color(0xFF0B0B1A) : c;
    return Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => setState(() => _down = true) : null,
        onTapCancel: enabled ? () => setState(() => _down = false) : null,
        onTapUp: enabled ? (_) => setState(() => _down = false) : null,
        onTap: enabled
            ? () {
                context.sfx.tap();
                widget.onTap!();
              }
            : null,
        child: AnimatedScale(
          scale: _down ? 0.96 : 1,
          duration: const Duration(milliseconds: 90),
          child: Container(
            height: widget.height,
            padding: const EdgeInsets.symmetric(horizontal: 22),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: widget.filled ? c : withAlphaF(c, 0.08),
              borderRadius: BorderRadius.circular(widget.height / 2),
              border: Border.all(color: c, width: 2),
              boxShadow: enabled
                  ? [
                      BoxShadow(
                        color: withAlphaF(c, widget.filled ? 0.5 : 0.25),
                        blurRadius: 18,
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  Icon(widget.icon, color: fg, size: widget.fontSize + 4),
                  const SizedBox(width: 8),
                ],
                Flexible(
                  child: Text(
                    widget.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: neonStyle(
                      context,
                      size: widget.fontSize,
                      color: fg,
                      weight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Dark rounded panel.
class NeonPanel extends StatelessWidget {
  const NeonPanel({
    super.key,
    required this.child,
    this.color = kCyan,
    this.padding = const EdgeInsets.all(16),
  });

  final Widget child;
  final Color color;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: withAlphaF(Palette.uiPanel, 0.92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: withAlphaF(color, 0.55), width: 1.5),
        boxShadow: [
          BoxShadow(color: withAlphaF(color, 0.18), blurRadius: 24),
        ],
      ),
      child: child,
    );
  }
}

/// A static runner pose, used on the home screen and in the shop.
class RunnerPreview extends StatelessWidget {
  const RunnerPreview({super.key, required this.color, this.size = 96});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _RunnerPreviewPainter(color)),
    );
  }
}

class _RunnerPreviewPainter extends CustomPainter {
  _RunnerPreviewPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.height * 0.85;
    drawRunner(
      canvas,
      feet: Offset(size.width / 2, size.height * 0.94),
      u: u,
      color: color,
      phase: math.pi * 0.3,
    );
  }

  @override
  bool shouldRepaint(covariant _RunnerPreviewPainter old) =>
      old.color != color;
}
