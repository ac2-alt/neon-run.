import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../app.dart';
import '../core/palette.dart';
import '../core/save.dart';
import '../game/engine.dart';
import '../game/entities.dart';
import '../game/renderer.dart';
import 'widgets.dart';

enum _Phase { tutorial, countdown, running, paused, dead }

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  static const double _swipeThreshold = 26;

  late final Ticker _ticker;
  Duration _last = Duration.zero;

  late GameEngine _engine;
  final RenderState _rs = RenderState();
  final List<Particle> _particles = [];
  final math.Random _fx = math.Random();

  /// Bumped every frame to repaint the canvas without rebuilding widgets.
  final ValueNotifier<int> _frame = ValueNotifier<int>(0);

  /// Bumped when something shown in the HUD changed.
  final ValueNotifier<int> _hud = ValueNotifier<int>(0);
  int _lastHudKey = 0;

  _Phase _phase = _Phase.countdown;
  double _countdown = 3;
  double _goFlash = 0;
  double _deadTimer = 0;
  bool _showResult = false;
  bool _recorded = false;
  bool _newBest = false;
  RunSummary? _result;

  int? _pointer;
  Offset? _origin;

  @override
  void initState() {
    super.initState();
    _engine = GameEngine();
    final scope = AppScope.read(context);
    _phase = scope.save.tutorialSeen ? _Phase.countdown : _Phase.tutorial;
    WidgetsBinding.instance.addObserver(this);
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    _frame.dispose();
    _hud.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _pause();
  }

  // ------------------------------------------------------------------ loop

  void _onTick(Duration elapsed) {
    var dt = (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;
    if (dt <= 0) return;
    dt = math.min(dt, 0.1);

    _rs.t += dt;
    _rs.shake = math.max(0, _rs.shake - dt * 2.2);
    _rs.flash = math.max(0, _rs.flash - dt * 3);
    if (_goFlash > 0) {
      _goFlash = math.max(0, _goFlash - dt);
      _bumpHud(force: true);
    }

    switch (_phase) {
      case _Phase.countdown:
        final before = _countdown.ceil();
        _countdown -= dt;
        if (_countdown <= 0) {
          _phase = _Phase.running;
          _goFlash = 0.6;
          setState(() {});
        } else if (_countdown.ceil() != before) {
          setState(() {});
        }
      case _Phase.running:
        final scroll = _engine.speed * math.min(dt, 0.05);
        _engine.update(dt);
        _handleEvents();
        _updateParticles(dt, scroll);
        _bumpHud();
        if (!_engine.alive) _die();
      case _Phase.dead:
        _rs.deathTime += dt;
        _updateParticles(dt, 0);
        _deadTimer += dt;
        if (!_showResult && _deadTimer > 0.9) {
          _showResult = true;
          setState(() {});
        }
      case _Phase.tutorial:
      case _Phase.paused:
        _updateParticles(dt, 0);
    }
    _frame.value++;
  }

  void _bumpHud({bool force = false}) {
    final e = _engine;
    final key = Object.hash(
      e.points,
      e.coins,
      e.shield,
      (e.magnetLeft * 10).ceil(),
      (e.doubleLeft * 10).ceil(),
    );
    if (force || key != _lastHudKey) {
      _lastHudKey = key;
      _hud.value++;
    }
  }

  void _updateParticles(double dt, double scroll) {
    if (_particles.isEmpty) return;
    for (final p in _particles) {
      p.update(dt, scroll);
    }
    _particles.removeWhere((p) => p.dead);
  }

  void _burst(Color color, int count, double speed,
      {double size = 0.12, double life = 0.6}) {
    final x = _engine.x * GamePainter.laneM;
    final y = _engine.y + 0.5;
    for (var i = 0; i < count; i++) {
      final a = _fx.nextDouble() * math.pi * 2;
      final s = speed * (0.4 + _fx.nextDouble() * 0.6);
      _particles.add(
        Particle(
          x: x,
          y: y,
          z: 0,
          vx: math.cos(a) * s,
          vy: math.sin(a).abs() * s + 1,
          vz: (_fx.nextDouble() - 0.3) * s,
          life: life * (0.6 + _fx.nextDouble() * 0.6),
          color: color,
          size: size,
        ),
      );
    }
  }

  void _handleEvents() {
    final sfx = AppScope.read(context).sfx;
    for (final e in _engine.takeEvents()) {
      switch (e) {
        case GameEvent.jump:
          sfx.play('jump');
        case GameEvent.slide:
          sfx.play('slide');
        case GameEvent.laneChange:
          sfx.buzz();
        case GameEvent.coin:
          sfx.play('coin');
          _burst(Palette.coin, 5, 3, size: 0.07, life: 0.4);
        case GameEvent.powerup:
          sfx.play('powerup');
          sfx.buzz();
          _burst(Colors.white, 14, 5, life: 0.6);
        case GameEvent.shieldBreak:
          sfx.play('shield_break');
          sfx.buzz(heavy: true);
          _rs.shake = 0.5;
          _burst(Palette.shield, 24, 7, life: 0.7);
        case GameEvent.crash:
          sfx.play('crash');
          sfx.buzz(heavy: true);
          _rs.shake = 1;
          _rs.flash = 1;
          _burst(Palette.skin(AppScope.read(context).save.skin).color, 40, 9,
              size: 0.16, life: 1.0);
          _burst(Colors.white, 16, 6, size: 0.1, life: 0.7);
      }
    }
  }

  void _die() {
    _phase = _Phase.dead;
    _deadTimer = 0;
    _rs.deathTime = 0;
    _finishRun();
    setState(() {});
  }

  /// Saves the run exactly once.
  void _finishRun() {
    if (_recorded) return;
    _recorded = true;
    final s = _engine.summary;
    _result = s;
    if (_engine.time < 1 && s.coins == 0) return;
    _newBest = AppScope.read(context).save.recordRun(
          RunStats(
            score: s.score,
            coins: s.coins,
            distance: s.distance,
            jumps: s.jumps,
            slides: s.slides,
            powerups: s.powerups,
          ),
        );
  }

  // --------------------------------------------------------------- actions

  void _pause() {
    if (_phase == _Phase.running || _phase == _Phase.countdown) {
      setState(() => _phase = _Phase.paused);
    }
  }

  void _resume() {
    setState(() {
      _phase = _Phase.countdown;
      _countdown = 2;
    });
  }

  void _restart() {
    setState(() {
      _engine = GameEngine();
      _particles.clear();
      _rs
        ..shake = 0
        ..flash = 0
        ..deathTime = 0;
      _phase = _Phase.countdown;
      _countdown = 3;
      _goFlash = 0;
      _deadTimer = 0;
      _showResult = false;
      _recorded = false;
      _newBest = false;
      _result = null;
      _lastHudKey = 0;
    });
  }

  void _home() {
    _finishRun();
    Navigator.of(context).pop();
  }

  void _onBack() {
    switch (_phase) {
      case _Phase.running:
      case _Phase.countdown:
        _pause();
      case _Phase.paused:
      case _Phase.dead:
      case _Phase.tutorial:
        _home();
    }
  }

  // ----------------------------------------------------------------- input

  void _onPointerDown(PointerDownEvent e) {
    _pointer = e.pointer;
    _origin = e.position;
  }

  void _onPointerMove(PointerMoveEvent e) {
    if (e.pointer != _pointer || _origin == null) return;
    if (_phase != _Phase.running) return;
    final d = e.position - _origin!;
    if (d.dx.abs() >= d.dy.abs()) {
      if (d.dx.abs() < _swipeThreshold) return;
      if (d.dx > 0) {
        _engine.moveRight();
      } else {
        _engine.moveLeft();
      }
    } else {
      if (d.dy.abs() < _swipeThreshold) return;
      if (d.dy < 0) {
        _engine.jump();
      } else {
        _engine.slide();
      }
    }
    _origin = e.position;
  }

  void _onPointerEnd(PointerEvent e) {
    if (e.pointer == _pointer) {
      _pointer = null;
      _origin = null;
    }
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent || _phase != _Phase.running) {
      return KeyEventResult.ignored;
    }
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowLeft) {
      _engine.moveLeft();
    } else if (k == LogicalKeyboardKey.arrowRight) {
      _engine.moveRight();
    } else if (k == LogicalKeyboardKey.arrowUp || k == LogicalKeyboardKey.space) {
      _engine.jump();
    } else if (k == LogicalKeyboardKey.arrowDown) {
      _engine.slide();
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  // ------------------------------------------------------------------ view

  @override
  Widget build(BuildContext context) {
    final save = context.save;
    final theme = Palette.theme(save.theme);
    final skin = Palette.skin(save.skin);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBack();
      },
      child: Scaffold(
        backgroundColor: Palette.uiBg,
        body: Focus(
          autofocus: true,
          onKeyEvent: _onKey,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: _onPointerDown,
                onPointerMove: _onPointerMove,
                onPointerUp: _onPointerEnd,
                onPointerCancel: _onPointerEnd,
                child: RepaintBoundary(
                  child: CustomPaint(
                    size: Size.infinite,
                    painter: GamePainter(
                      engine: _engine,
                      rs: _rs,
                      particles: _particles,
                      theme: theme,
                      skin: skin.color,
                      repaint: _frame,
                    ),
                  ),
                ),
              ),
              _buildHud(),
              _buildGoFlash(),
              if (_phase == _Phase.countdown) _buildCountdown(),
              if (_phase == _Phase.tutorial) _buildTutorial(),
              if (_phase == _Phase.paused) _buildPause(),
              if (_phase == _Phase.dead && _showResult) _buildResult(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHud() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: ValueListenableBuilder<int>(
          valueListenable: _hud,
          builder: (context, _, __) {
            final e = _engine;
            final best = math.max(context.save.best, e.points);
            return Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _RoundIconButton(
                      icon: Icons.pause_rounded,
                      onTap: (_phase == _Phase.running ||
                              _phase == _Phase.countdown)
                          ? _pause
                          : null,
                    ),
                    Expanded(
                      child: IgnorePointer(
                        child: Column(
                          children: [
                            Text(
                              context.n(e.points),
                              style: neonStyle(
                                context,
                                size: 38,
                                weight: FontWeight.w900,
                                glow: true,
                              ),
                            ),
                            Text(
                              '${context.t('best')} ${context.n(best)}',
                              style: neonStyle(
                                context,
                                size: 13,
                                color: Palette.uiMuted,
                                weight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    IgnorePointer(child: CoinChip(value: e.coins)),
                  ],
                ),
                const SizedBox(height: 10),
                IgnorePointer(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (e.shield)
                        const _PowerBadge(
                          color: Palette.shield,
                          fraction: 1,
                          child: Icon(Icons.shield_rounded,
                              color: Palette.shield, size: 24),
                        ),
                      if (e.magnetLeft > 0)
                        _PowerBadge(
                          color: Palette.magnet,
                          fraction: e.magnetLeft / GameEngine.magnetTime,
                          child: const _MagnetGlyph(color: Palette.magnet),
                        ),
                      if (e.doubleLeft > 0)
                        _PowerBadge(
                          color: Palette.doubleScore,
                          fraction: e.doubleLeft / GameEngine.doubleTime,
                          child: const Text(
                            '2x',
                            style: TextStyle(
                              color: Palette.doubleScore,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildCountdown() {
    final n = _countdown.ceil().clamp(1, 3);
    return IgnorePointer(
      child: Center(
        child: Text(
          context.n(n),
          style: neonStyle(
            context,
            size: 120,
            weight: FontWeight.w900,
            color: kCyan,
            glow: true,
          ),
        ),
      ),
    );
  }

  Widget _buildGoFlash() {
    return IgnorePointer(
      child: ValueListenableBuilder<int>(
        valueListenable: _hud,
        builder: (context, _, __) {
          if (_goFlash <= 0) return const SizedBox.shrink();
          return Center(
            child: Opacity(
              opacity: (_goFlash / 0.6).clamp(0.0, 1.0),
              child: Text(
                context.t('go'),
                style: neonStyle(
                  context,
                  size: 90,
                  weight: FontWeight.w900,
                  color: Palette.coin,
                  glow: true,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _scrim({required Widget child}) {
    return Positioned.fill(
      child: Container(
        color: withAlphaF(Palette.uiBg, 0.78),
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: child,
      ),
    );
  }

  Widget _buildTutorial() {
    Widget row(IconData icon, String key, Color color) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Icon(icon, color: color, size: 30),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  context.t(key),
                  style: neonStyle(context,
                      size: 16, weight: FontWeight.w600),
                ),
              ),
            ],
          ),
        );
    return _scrim(
      child: NeonPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              context.t('tutorial_title'),
              style: neonStyle(context,
                  size: 24, weight: FontWeight.w900, color: kCyan, glow: true),
            ),
            const SizedBox(height: 12),
            row(Icons.swap_horiz_rounded, 'tut_swipe', kCyan),
            row(Icons.keyboard_double_arrow_up_rounded, 'tut_up', Palette.coin),
            row(Icons.keyboard_double_arrow_down_rounded, 'tut_down', kPink),
            row(Icons.stars_rounded, 'tut_items', Palette.doubleScore),
            const SizedBox(height: 16),
            NeonButton(
              label: context.t('got_it'),
              onTap: () {
                context.save.markTutorialSeen();
                setState(() {
                  _phase = _Phase.countdown;
                  _countdown = 3;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPause() {
    return _scrim(
      child: NeonPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              context.t('paused'),
              style: neonStyle(context,
                  size: 28, weight: FontWeight.w900, color: kCyan, glow: true),
            ),
            const SizedBox(height: 20),
            NeonButton(
              label: context.t('resume'),
              icon: Icons.play_arrow_rounded,
              onTap: _resume,
            ),
            const SizedBox(height: 12),
            NeonButton(
              label: context.t('restart'),
              icon: Icons.replay_rounded,
              filled: false,
              color: Palette.coin,
              onTap: () {
                _finishRun();
                _restart();
              },
            ),
            const SizedBox(height: 12),
            NeonButton(
              label: context.t('home'),
              icon: Icons.home_rounded,
              filled: false,
              color: kPink,
              onTap: _home,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResult() {
    final r = _result;
    final best = context.save.best;
    Widget stat(String label, String value, Color color) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: neonStyle(context,
                      size: 15,
                      color: Palette.uiMuted,
                      weight: FontWeight.w600),
                ),
              ),
              Text(value,
                  style: neonStyle(context,
                      size: 18, color: color, weight: FontWeight.w800)),
            ],
          ),
        );
    return _scrim(
      child: NeonPanel(
        color: _newBest ? Palette.coin : kPink,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _newBest ? context.t('new_best') : context.t('game_over'),
              style: neonStyle(
                context,
                size: 28,
                weight: FontWeight.w900,
                color: _newBest ? Palette.coin : kPink,
                glow: true,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              context.n(r?.score ?? 0),
              style: neonStyle(context,
                  size: 54, weight: FontWeight.w900, glow: true),
            ),
            const SizedBox(height: 10),
            stat(context.t('best'), context.n(best), Palette.coin),
            stat(
              context.t('distance'),
              '${context.n(r?.distance ?? 0)} ${context.t('meters')}',
              kCyan,
            ),
            stat(context.t('coins'), '+${context.n(r?.coins ?? 0)}',
                Palette.coin),
            const SizedBox(height: 18),
            NeonButton(
              label: context.t('restart'),
              icon: Icons.replay_rounded,
              onTap: _restart,
            ),
            const SizedBox(height: 12),
            NeonButton(
              label: context.t('home'),
              icon: Icons.home_rounded,
              filled: false,
              color: kPink,
              onTap: _home,
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap == null
          ? null
          : () {
              context.sfx.tap();
              onTap!();
            },
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: withAlphaF(Palette.uiPanel, 0.85),
          border: Border.all(color: withAlphaF(kCyan, 0.6), width: 1.5),
        ),
        child: Icon(icon, color: Palette.uiText),
      ),
    );
  }
}

class _PowerBadge extends StatelessWidget {
  const _PowerBadge({
    required this.color,
    required this.fraction,
    required this.child,
  });

  final Color color;
  final double fraction;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      width: 50,
      height: 50,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 46,
            height: 46,
            child: CircularProgressIndicator(
              value: fraction.clamp(0.0, 1.0),
              strokeWidth: 3,
              color: color,
              backgroundColor: withAlphaF(color, 0.2),
            ),
          ),
          child,
        ],
      ),
    );
  }
}

class _MagnetGlyph extends StatelessWidget {
  const _MagnetGlyph({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(size: const Size(24, 24), painter: _MagnetPainter(color));
  }
}

class _MagnetPainter extends CustomPainter {
  _MagnetPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.butt;
    final w = size.width, h = size.height;
    final arc = Rect.fromLTWH(w * 0.14, h * 0.08, w * 0.72, w * 0.72);
    canvas.drawArc(arc, math.pi, math.pi, false, p);
    canvas.drawLine(Offset(w * 0.14, h * 0.44), Offset(w * 0.14, h * 0.88), p);
    canvas.drawLine(Offset(w * 0.86, h * 0.44), Offset(w * 0.86, h * 0.88), p);
  }

  @override
  bool shouldRepaint(covariant _MagnetPainter old) => old.color != color;
}
