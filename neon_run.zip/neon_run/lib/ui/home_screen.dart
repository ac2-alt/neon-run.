import 'package:flutter/material.dart';

import '../app.dart';
import '../core/missions.dart';
import '../core/palette.dart';
import 'game_screen.dart';
import 'missions_screen.dart';
import 'settings_screen.dart';
import 'shop_screen.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _float = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  bool _musicStarted = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_musicStarted) {
      _musicStarted = true;
      context.sfx.startMusic();
    }
  }

  @override
  void dispose() {
    _float.dispose();
    super.dispose();
  }

  void _push(Widget page) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 220),
        reverseTransitionDuration: const Duration(milliseconds: 180),
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  bool get _hasClaimable {
    for (final m in context.save.missions) {
      final def = MissionPool.byId(m.id);
      if (!m.claimed && m.progress >= def.target) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final save = context.save;
    final skin = Palette.skin(save.skin);
    final theme = Palette.theme(save.theme);

    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [CoinChip(value: save.coins)],
                ),
                const Spacer(flex: 2),
                Text(
                  context.t('app'),
                  textAlign: TextAlign.center,
                  style: neonStyle(
                    context,
                    size: 52,
                    weight: FontWeight.w900,
                    color: theme.rail,
                    glow: true,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  context.t('tagline'),
                  textAlign: TextAlign.center,
                  style: neonStyle(
                    context,
                    size: 16,
                    color: Palette.uiText.withAlpha(200),
                    weight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                AnimatedBuilder(
                  animation: _float,
                  builder: (context, child) => Transform.translate(
                    offset: Offset(0, -10 * Curves.easeInOut.transform(_float.value)),
                    child: child,
                  ),
                  child: RunnerPreview(
                    color: skin.color,
                    size: MediaQuery.sizeOf(context).height < 680 ? 96 : 140,
                  ),
                ),
                const SizedBox(height: 14),
                if (save.best > 0)
                  Text(
                    '${context.t('best')}: ${context.n(save.best)}',
                    style: neonStyle(
                      context,
                      size: 18,
                      color: Palette.coin,
                      glow: true,
                    ),
                  ),
                const Spacer(),
                NeonButton(
                  label: context.t('play'),
                  icon: Icons.play_arrow_rounded,
                  fontSize: 24,
                  height: 66,
                  color: theme.rail,
                  onTap: () => _push(const GameScreen()),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: NeonButton(
                        label: context.t('shop'),
                        icon: Icons.storefront_rounded,
                        filled: false,
                        fontSize: 15,
                        height: 50,
                        color: kPink,
                        onTap: () => _push(const ShopScreen()),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          NeonButton(
                            label: context.t('missions'),
                            icon: Icons.flag_rounded,
                            filled: false,
                            fontSize: 15,
                            height: 50,
                            color: Palette.coin,
                            onTap: () => _push(const MissionsScreen()),
                          ),
                          if (_hasClaimable)
                            Positioned(
                              top: -2,
                              right: -2,
                              child: Container(
                                width: 16,
                                height: 16,
                                decoration: BoxDecoration(
                                  color: kPink,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Palette.uiBg,
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                NeonButton(
                  label: context.t('settings'),
                  icon: Icons.settings_rounded,
                  filled: false,
                  fontSize: 15,
                  height: 46,
                  color: Palette.uiMuted,
                  onTap: () => _push(const SettingsScreen()),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
