import 'package:flutter/material.dart';

import '../app.dart';
import '../core/l10n.dart';
import '../core/missions.dart';
import '../core/palette.dart';
import '../core/save.dart';
import 'widgets.dart';

class MissionsScreen extends StatelessWidget {
  const MissionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final save = context.save;
    return ScreenFrame(
      title: context.t('missions'),
      trailing: CoinChip(value: save.coins),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              context.t('daily_missions'),
              style: neonStyle(context, size: 18, color: Palette.uiMuted),
            ),
          ),
          for (final m in save.missions) ...[
            _MissionCard(progress: m),
            const SizedBox(height: 12),
          ],
          const SizedBox(height: 8),
          Text(
            context.t('missions_hint'),
            textAlign: TextAlign.center,
            style: neonStyle(
              context,
              size: 13,
              color: Palette.uiMuted,
              weight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  const _MissionCard({required this.progress});

  final MissionProgress progress;

  @override
  Widget build(BuildContext context) {
    final def = MissionPool.byId(progress.id);
    final done = progress.progress >= def.target;
    final shown = progress.progress.clamp(0, def.target);
    final fraction = def.target == 0 ? 1.0 : shown / def.target;
    final accent = progress.claimed
        ? Palette.uiMuted
        : (done ? Palette.coin : kCyan);

    return NeonPanel(
      color: accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            S.mission(context.lang, def),
            style: neonStyle(context, size: 17),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: fraction,
              minHeight: 10,
              color: accent,
              backgroundColor: withAlphaF(accent, 0.18),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                '${context.n(shown)} / ${context.n(def.target)}',
                style: neonStyle(
                  context,
                  size: 14,
                  color: Palette.uiMuted,
                  weight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              const CoinIcon(size: 16),
              const SizedBox(width: 6),
              Text(
                '+${context.n(def.reward)}',
                style: neonStyle(context, size: 15, color: Palette.coin),
              ),
            ],
          ),
          if (done) ...[
            const SizedBox(height: 12),
            NeonButton(
              label: progress.claimed
                  ? context.t('claimed')
                  : context.t('claim'),
              icon: progress.claimed ? Icons.check_rounded : null,
              color: Palette.coin,
              height: 44,
              fontSize: 15,
              onTap: progress.claimed
                  ? null
                  : () {
                      if (context.save.claim(progress.id)) {
                        context.sfx.play('mission');
                      }
                    },
            ),
          ],
        ],
      ),
    );
  }
}
