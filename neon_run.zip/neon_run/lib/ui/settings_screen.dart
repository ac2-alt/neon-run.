import 'package:flutter/material.dart';

import '../app.dart';
import '../core/palette.dart';
import 'widgets.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _confirmReset(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Palette.uiPanel,
        content: Text(
          ctx.t('reset_confirm'),
          style: neonStyle(ctx, size: 16, weight: FontWeight.w500),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(ctx.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              ctx.t('confirm'),
              style: const TextStyle(color: kPink),
            ),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      await context.save.resetAll();
      if (context.mounted) context.sfx.syncMusicSetting();
    }
  }

  @override
  Widget build(BuildContext context) {
    final save = context.save;
    return ScreenFrame(
      title: context.t('settings'),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          NeonPanel(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                _SwitchRow(
                  label: context.t('sound'),
                  value: save.sound,
                  onChanged: save.setSound,
                ),
                _SwitchRow(
                  label: context.t('music'),
                  value: save.music,
                  onChanged: (v) {
                    save.setMusic(v);
                    context.sfx.syncMusicSetting();
                  },
                ),
                _SwitchRow(
                  label: context.t('vibration'),
                  value: save.haptic,
                  onChanged: save.setHaptic,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          NeonPanel(
            color: kPink,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('language'), style: neonStyle(context, size: 16)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: NeonButton(
                        label: context.t('persian'),
                        filled: save.lang == 'fa',
                        color: kPink,
                        height: 44,
                        fontSize: 15,
                        onTap: () => save.setLang('fa'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: NeonButton(
                        label: context.t('english'),
                        filled: save.lang == 'en',
                        color: kPink,
                        height: 44,
                        fontSize: 15,
                        onTap: () => save.setLang('en'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          NeonPanel(
            color: Palette.coin,
            child: Column(
              children: [
                _StatRow(context.t('best'), context.n(save.best)),
                _StatRow(context.t('runs'), context.n(save.runs)),
                _StatRow(
                  context.t('total_distance'),
                  '${context.n(save.totalDistance)} ${context.t('meters')}',
                ),
                _StatRow(
                    context.t('lifetime_coins'), context.n(save.lifetimeCoins)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          NeonPanel(
            color: Palette.uiMuted,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.t('about'), style: neonStyle(context, size: 16)),
                const SizedBox(height: 8),
                Text(
                  context.t('about_text'),
                  style: neonStyle(
                    context,
                    size: 14,
                    color: Palette.uiMuted,
                    weight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${context.t('version')} 1.0.0',
                  style: neonStyle(
                    context,
                    size: 13,
                    color: Palette.uiMuted,
                    weight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          NeonButton(
            label: context.t('reset'),
            icon: Icons.delete_outline_rounded,
            filled: false,
            color: kPink,
            height: 48,
            fontSize: 15,
            onTap: () => _confirmReset(context),
          ),
        ],
      ),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  const _SwitchRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(label, style: neonStyle(context, size: 16))),
        Switch(
          value: value,
          onChanged: (v) {
            context.sfx.tap();
            onChanged(v);
          },
        ),
      ],
    );
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: neonStyle(
                context,
                size: 15,
                color: Palette.uiMuted,
                weight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: neonStyle(context, size: 16, color: Palette.coin),
          ),
        ],
      ),
    );
  }
}
