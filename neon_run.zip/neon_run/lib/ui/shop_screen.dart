import 'package:flutter/material.dart';

import '../app.dart';
import '../core/palette.dart';
import 'widgets.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final save = context.save;
    return ScreenFrame(
      title: context.t('shop'),
      trailing: CoinChip(value: save.coins),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          _Section(title: context.t('skins')),
          _Grid(
            children: [
              for (final s in Palette.skins)
                _ShopCard(
                  name: s.name(context.lang),
                  price: s.price,
                  owned: save.ownedSkins.contains(s.id),
                  selected: save.skin == s.id,
                  accent: s.color,
                  preview: RunnerPreview(color: s.color, size: 84),
                  onBuy: () => save.buySkin(s.id, s.price),
                  onEquip: () => save.equipSkin(s.id),
                ),
            ],
          ),
          const SizedBox(height: 20),
          _Section(title: context.t('themes')),
          _Grid(
            children: [
              for (final t in Palette.themes)
                _ShopCard(
                  name: t.name(context.lang),
                  price: t.price,
                  owned: save.ownedThemes.contains(t.id),
                  selected: save.theme == t.id,
                  accent: t.rail,
                  preview: _ThemeSwatch(theme: t),
                  onBuy: () => save.buyTheme(t.id, t.price),
                  onEquip: () => save.equipTheme(t.id),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(
        title,
        style: neonStyle(context, size: 18, color: Palette.uiMuted),
      ),
    );
  }
}

class _Grid extends StatelessWidget {
  const _Grid({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        const gap = 12.0;
        final w = (box.maxWidth - gap) / 2;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final c in children) SizedBox(width: w, child: c),
          ],
        );
      },
    );
  }
}

class _ThemeSwatch extends StatelessWidget {
  const _ThemeSwatch({required this.theme});

  final NeonTheme theme;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 84,
      height: 84,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.bgTop, theme.bgBottom],
        ),
        border: Border.all(color: withAlphaF(theme.rail, 0.8), width: 2),
      ),
      child: CustomPaint(painter: _SwatchPainter(theme)),
    );
  }
}

class _SwatchPainter extends CustomPainter {
  _SwatchPainter(this.theme);

  final NeonTheme theme;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final hy = h * 0.45;
    final rail = Paint()
      ..color = theme.rail
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final lane = Paint()
      ..color = withAlphaF(theme.laneLine, 0.9)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(w * 0.45, hy), Offset(w * 0.1, h), rail);
    canvas.drawLine(Offset(w * 0.55, hy), Offset(w * 0.9, h), rail);
    canvas.drawLine(Offset(w * 0.5, hy), Offset(w * 0.5, h), lane);
    canvas.drawRect(
      Rect.fromLTWH(w * 0.4, h * 0.62, w * 0.2, h * 0.14),
      Paint()..color = theme.obstacle,
    );
    canvas.drawCircle(
      Offset(w * 0.5, hy - 6),
      w * 0.12,
      Paint()..color = withAlphaF(theme.rail, 0.7),
    );
  }

  @override
  bool shouldRepaint(covariant _SwatchPainter old) => old.theme != theme;
}

class _ShopCard extends StatelessWidget {
  const _ShopCard({
    required this.name,
    required this.price,
    required this.owned,
    required this.selected,
    required this.accent,
    required this.preview,
    required this.onBuy,
    required this.onEquip,
  });

  final String name;
  final int price;
  final bool owned;
  final bool selected;
  final Color accent;
  final Widget preview;
  final bool Function() onBuy;
  final VoidCallback onEquip;

  @override
  Widget build(BuildContext context) {
    final String label;
    VoidCallback? action;
    Color color = accent;
    IconData? icon;

    if (selected) {
      label = context.t('selected');
      icon = Icons.check_circle_rounded;
      action = null;
    } else if (owned) {
      label = context.t('equip');
      action = onEquip;
    } else {
      label = context.n(price);
      action = () {
        if (!onBuy()) {
          ScaffoldMessenger.of(context)
            ..clearSnackBars()
            ..showSnackBar(
              SnackBar(
                content: Text(context.t('not_enough')),
                duration: const Duration(milliseconds: 1400),
                behavior: SnackBarBehavior.floating,
              ),
            );
        } else {
          context.sfx.play('mission');
        }
      };
      icon = Icons.lock_rounded;
    }
    if (color.computeLuminance() < 0.15) color = kCyan;

    return NeonPanel(
      color: selected ? Palette.coin : accent,
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
      child: Column(
        children: [
          preview,
          const SizedBox(height: 10),
          Text(
            name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: neonStyle(context, size: 15),
          ),
          const SizedBox(height: 10),
          NeonButton(
            label: label,
            icon: icon,
            filled: !selected && owned,
            color: selected ? Palette.coin : color,
            height: 42,
            fontSize: 14,
            onTap: action,
          ),
        ],
      ),
    );
  }
}
