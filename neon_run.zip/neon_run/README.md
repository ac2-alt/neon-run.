# NeonRun

A free, offline, three-lane neon arcade runner for Android, built with Flutter.
No ads, no accounts, no internet permission: all data stays on the device.

نئون‌ران؛ یک بازی آرکید دوندهٔ سه‌خطه، رایگان و کاملاً آفلاین.

## Features

- Three lanes: swipe left/right to switch, up to jump, down to slide
- Gradually increasing speed, obstacles, coins and power-ups (shield, magnet, x2)
- Persistent best score and coin wallet
- Shop with unlockable runner colors and themes
- Three daily missions
- Procedurally generated sound effects and music (no copyrighted assets)
- Persian and English, with right-to-left layout

## Get the APK (no setup on your computer)

1. Create a new empty repository on GitHub.
2. Upload all files of this project to it, including the hidden `.github` folder.
3. Open the **Actions** tab, choose **Build APK**, then **Run workflow**.
4. When it finishes, open the run and download the **NeonRun-apk** artifact.
5. Unzip it and install `app-release.apk` on your phone (allow installing from unknown sources).

## Build locally

```bash
flutter create --platforms=android --org com.neonrun --project-name neon_run .
flutter pub get
dart run flutter_launcher_icons
flutter run
```

## Regenerate audio and icons

```bash
python3 tools/make_audio.py
python3 tools/make_icons.py
```

## Project layout

```
lib/
  main.dart            app entry
  app.dart             theme, localization, routes
  core/                save data, strings, palette, audio, missions
  game/                pure Dart engine, level generator and the 3D painter
  ui/                  home, game, shop, missions and settings screens
  ui/                  screens and shared widgets
test/                  engine and data tests
tools/                 asset generators
```

## License

MIT
