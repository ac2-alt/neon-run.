"""Generate all NeonRun sound effects and the music loop as 16-bit mono WAV files.

Everything is synthesized from scratch, so there are no licensing concerns.
Requires only numpy.
"""
import os
import wave

import numpy as np

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "audio")
os.makedirs(OUT, exist_ok=True)


def save(name, data):
    data = np.clip(data, -1.0, 1.0)
    pcm = (data * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(pcm.tobytes())


def t(sec):
    return np.linspace(0, sec, int(SR * sec), endpoint=False)


def env(n, attack=0.01, release=0.2):
    e = np.ones(n)
    a = max(1, int(SR * attack))
    r = max(1, int(SR * release))
    e[:a] = np.linspace(0, 1, a)
    e[-r:] = np.minimum(e[-r:], np.linspace(1, 0, r))
    return e


def sweep(f0, f1, sec, wave_fn=np.sin):
    x = t(sec)
    freq = np.linspace(f0, f1, len(x))
    phase = 2 * np.pi * np.cumsum(freq) / SR
    return wave_fn(phase)


def square(p):
    return np.sign(np.sin(p))


def tri(p):
    return 2 / np.pi * np.arcsin(np.sin(p))


rng = np.random.default_rng(7)

# --- sound effects ---
d = sweep(500, 1400, 0.16, square) * 0.4
save("jump.wav", d * env(len(d), 0.005, 0.1))

d = sweep(900, 1800, 0.09, tri) * 0.5
d = np.concatenate([d, sweep(1200, 2400, 0.12, tri) * 0.5])
save("coin.wav", d * env(len(d), 0.003, 0.08))

d = sweep(300, 120, 0.12, tri) * 0.5
save("slide.wav", d * env(len(d), 0.005, 0.08))

n = t(0.5)
d = (rng.uniform(-1, 1, len(n)) * 0.6 + sweep(200, 40, 0.5, square) * 0.5)
save("crash.wav", d * env(len(d), 0.002, 0.45))

parts = [sweep(f, f * 1.5, 0.08, tri) * 0.5 for f in (500, 650, 800, 1000)]
d = np.concatenate(parts)
save("powerup.wav", d * env(len(d), 0.003, 0.1))

d = sweep(1500, 600, 0.3, tri) * 0.5
save("shield_break.wav", d * env(len(d), 0.003, 0.25))

d = sweep(400, 600, 0.06, square) * 0.3
save("click.wav", d * env(len(d), 0.002, 0.04))

d = np.concatenate([sweep(f, f, 0.12, tri) * 0.5 for f in (523, 659, 784, 1047)])
save("mission.wav", d * env(len(d), 0.003, 0.12))

# --- music loop: 16 beats at 124 bpm, A minor ---
bpm = 124
beat = 60 / bpm
bars = 4
total = bars * 4 * beat
n_total = int(SR * total)
music = np.zeros(n_total)


def add(start, sig):
    i = int(SR * start)
    j = min(n_total, i + len(sig))
    music[i:j] += sig[: j - i]


def note(freq, sec, kind=tri, vol=0.3):
    x = t(sec)
    sig = kind(2 * np.pi * freq * x) * vol
    return sig * env(len(sig), 0.005, min(0.12, sec * 0.8))


def kick():
    s = sweep(150, 45, 0.18, np.sin) * 0.8
    return s * env(len(s), 0.001, 0.16)


def hat():
    s = rng.uniform(-1, 1, int(SR * 0.04)) * 0.15
    return s * env(len(s), 0.001, 0.035)


bass_pattern = [55.0, 55.0, 65.41, 49.0]  # A1 A1 C2 G1 per bar
arp_notes = [220.0, 261.63, 329.63, 261.63, 196.0, 246.94, 293.66, 246.94]
for bar in range(bars):
    root = bass_pattern[bar]
    for b in range(4):
        st = (bar * 4 + b) * beat
        add(st, kick())
        add(st + beat / 2, hat())
        add(st, note(root, beat * 0.45, square, 0.16))
        add(st + beat / 2, note(root, beat * 0.4, square, 0.12))
    for e in range(8):
        st = (bar * 8 + e) * beat / 2
        base = arp_notes[e] * (0.89 if bar == 3 else 1.0)
        add(st, note(base * 2, beat * 0.4, tri, 0.12))

music = music / max(1e-6, np.max(np.abs(music))) * 0.8
# short fade at loop edges to avoid clicks
f = int(SR * 0.005)
music[:f] *= np.linspace(0, 1, f)
music[-f:] *= np.linspace(1, 0, f)
save("music.wav", music)

print("audio written to", os.path.abspath(OUT))
for fn in sorted(os.listdir(OUT)):
    print(" ", fn, os.path.getsize(os.path.join(OUT, fn)) // 1024, "KB")
