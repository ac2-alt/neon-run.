"""Generate the NeonRun launcher icon (full + adaptive foreground) with Pillow."""
import os

from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "icon")
os.makedirs(OUT, exist_ok=True)

SIZE = 1024
BG = (11, 11, 26)
CYAN = (0, 240, 255)
MAGENTA = (255, 0, 200)


def glow_layer(draw_fn, blur):
    layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(layer))
    return layer.filter(ImageFilter.GaussianBlur(blur))


def road(d, scale=1.0):
    c = SIZE / 2
    top = SIZE * (0.5 - 0.30 * scale)
    bot = SIZE * (0.5 + 0.34 * scale)
    wt = SIZE * 0.07 * scale
    wb = SIZE * 0.34 * scale
    # outer rails
    d.line([(c - wt, top), (c - wb, bot)], fill=CYAN + (255,), width=int(SIZE * 0.035 * scale))
    d.line([(c + wt, top), (c + wb, bot)], fill=CYAN + (255,), width=int(SIZE * 0.035 * scale))
    # lane dividers
    for k in (-1 / 3, 1 / 3):
        d.line([(c + wt * k, top), (c + wb * k, bot)], fill=MAGENTA + (255,),
               width=int(SIZE * 0.022 * scale))
    # runner diamond
    r = SIZE * 0.11 * scale
    cy = SIZE * 0.66
    d.polygon([(c, cy - r), (c + r, cy), (c, cy + r), (c - r, cy)], fill=(255, 255, 255, 255))


def compose(scale, with_bg):
    img = Image.new("RGBA", (SIZE, SIZE), BG + (255,) if with_bg else (0, 0, 0, 0))
    img.alpha_composite(glow_layer(lambda d: road(d, scale), 28))
    img.alpha_composite(glow_layer(lambda d: road(d, scale), 10))
    sharp = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    road(ImageDraw.Draw(sharp), scale)
    img.alpha_composite(sharp)
    return img


# full icon: fills the canvas
compose(1.0, True).save(os.path.join(OUT, "icon.png"))
# adaptive foreground: art kept inside the central safe zone (66%)
compose(0.62, False).save(os.path.join(OUT, "icon_fg.png"))
print("icons written to", os.path.abspath(OUT))
