import 'package:flutter_test/flutter_test.dart';
import 'package:neon_run/core/l10n.dart';
import 'package:neon_run/core/missions.dart';
import 'package:neon_run/core/save.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  final day1 = DateTime(2026, 11, 8);
  final day2 = DateTime(2026, 11, 9);

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('MissionPool', () {
    test('picks three missions with distinct kinds, same result per day', () {
      final a = MissionPool.forDate(day1);
      final b = MissionPool.forDate(day1);
      expect(a.length, 3);
      expect(a.map((m) => m.id).toList(), b.map((m) => m.id).toList());
      expect(a.map((m) => m.kind).toSet().length, 3);
    });

    test('every pool entry can be looked up', () {
      for (final m in MissionPool.all) {
        expect(MissionPool.byId(m.id).id, m.id);
      }
    });
  });

  group('SaveData', () {
    test('starts with defaults and three missions', () async {
      final s = await SaveData.load(now: day1);
      expect(s.coins, 0);
      expect(s.best, 0);
      expect(s.skin, 'white');
      expect(s.theme, 'synth');
      expect(s.missions.length, 3);
    });

    test('recordRun updates best, coins and persists', () async {
      final s = await SaveData.load(now: day1);
      final isBest = s.recordRun(
        const RunStats(score: 1500, coins: 30, distance: 900, jumps: 5),
        now: day1,
      );
      expect(isBest, isTrue);
      expect(s.best, 1500);
      expect(s.coins, 30);
      expect(s.runs, 1);
      final worse = s.recordRun(const RunStats(score: 100), now: day1);
      expect(worse, isFalse);
      expect(s.best, 1500);

      final reloaded = await SaveData.load(now: day1);
      expect(reloaded.best, 1500);
      expect(reloaded.coins, 30);
      expect(reloaded.runs, 2);
    });

    test('missions progress, can be claimed once', () async {
      final s = await SaveData.load(now: day1);
      s.recordRun(
        const RunStats(
          score: 99999,
          coins: 9999,
          distance: 99999,
          jumps: 999,
          slides: 999,
          powerups: 999,
        ),
        now: day1,
      );
      final before = s.coins;
      final id = s.missions.first.id;
      final reward = MissionPool.byId(id).reward;
      expect(s.claim(id), isTrue);
      expect(s.coins, before + reward);
      expect(s.claim(id), isFalse);
    });

    test('cannot claim an unfinished mission', () async {
      final s = await SaveData.load(now: day1);
      expect(s.claim(s.missions.first.id), isFalse);
    });

    test('missions reset on a new day', () async {
      final s = await SaveData.load(now: day1);
      s.recordRun(const RunStats(coins: 10, distance: 100), now: day1);
      final changed = s.refreshMissions(now: day2);
      expect(changed, isTrue);
      expect(s.missions.every((m) => m.progress == 0 && !m.claimed), isTrue);
      expect(s.refreshMissions(now: day2), isFalse);
    });

    test('shop: buy needs coins, equip needs ownership', () async {
      final s = await SaveData.load(now: day1);
      expect(s.buySkin('cyan', 150), isFalse);
      s.recordRun(const RunStats(coins: 200), now: day1);
      expect(s.buySkin('cyan', 150), isTrue);
      expect(s.coins, 50);
      expect(s.skin, 'cyan');
      expect(s.buySkin('cyan', 150), isFalse);
      s.equipSkin('lime');
      expect(s.skin, 'cyan');
      s.equipSkin('white');
      expect(s.skin, 'white');
      expect(s.buyTheme('matrix', 300), isFalse);
    });

    test('resetAll restores defaults', () async {
      final s = await SaveData.load(now: day1);
      s.recordRun(const RunStats(score: 500, coins: 500), now: day1);
      s.buySkin('cyan', 150);
      await s.resetAll();
      expect(s.coins, 0);
      expect(s.best, 0);
      expect(s.ownedSkins, {'white'});
      expect(s.missions.length, 3);
    });
  });

  group('S (strings)', () {
    test('every English key exists in Persian too', () {
      // Spot-check a representative set of keys used by the UI.
      for (final key in ['play', 'shop', 'missions', 'settings', 'game_over']) {
        expect(S.t('fa', key), isNot(key));
        expect(S.t('en', key), isNot(key));
      }
    });

    test('number formatting', () {
      expect(S.num('en', 1234567), '1,234,567');
      expect(S.num('en', 0), '0');
      expect(S.num('fa', 1200), '۱٬۲۰۰');
      expect(S.num('en', -5), '-5');
    });

    test('mission text substitutes the target', () {
      final text = S.mission('en', const MissionDef('x', MissionKind.coins, 50, 1));
      expect(text, 'Collect 50 coins');
    });
  });
}
