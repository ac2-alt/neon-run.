import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:neon_run/game/engine.dart';
import 'package:neon_run/game/entities.dart';

GameEngine _emptyEngine() {
  final e = GameEngine(random: math.Random(1));
  e.world.obstacles.clear();
  e.world.coins.clear();
  e.world.powerUps.clear();
  return e;
}

void _run(GameEngine e, double seconds) {
  var t = 0.0;
  while (t < seconds && e.alive) {
    e.update(1 / 60);
    t += 1 / 60;
  }
}

void main() {
  test('starts alive in the middle lane', () {
    final e = GameEngine(random: math.Random(1));
    expect(e.alive, isTrue);
    expect(e.lane, 1);
    expect(e.grounded, isTrue);
  });

  test('lane changes are clamped to 0..2', () {
    final e = _emptyEngine();
    e.moveLeft();
    e.moveLeft();
    e.moveLeft();
    expect(e.lane, 0);
    e.moveRight();
    e.moveRight();
    e.moveRight();
    e.moveRight();
    expect(e.lane, 2);
  });

  test('a jump leaves the ground and lands again', () {
    final e = _emptyEngine();
    e.jump();
    e.update(1 / 60);
    expect(e.grounded, isFalse);
    _run(e, 1.2);
    expect(e.grounded, isTrue);
    expect(e.y, 0);
  });

  test('a slide ends by itself', () {
    final e = _emptyEngine();
    e.slide();
    expect(e.sliding, isTrue);
    _run(e, 0.8);
    expect(e.sliding, isFalse);
  });

  test('hitting a wall ends the run', () {
    final e = _emptyEngine();
    e.world.obstacles.add(Obstacle(1, ObstacleKind.block, 5));
    _run(e, 1);
    expect(e.alive, isFalse);
    expect(e.takeEvents(), contains(GameEvent.crash));
  });

  test('jumping clears a low barrier', () {
    final e = _emptyEngine();
    e.world.obstacles.add(Obstacle(1, ObstacleKind.low, 5));
    e.jump();
    _run(e, 0.6);
    expect(e.alive, isTrue);
  });

  test('sliding passes under a high bar', () {
    final e = _emptyEngine();
    e.world.obstacles.add(Obstacle(1, ObstacleKind.high, 5));
    e.slide();
    _run(e, 0.6);
    expect(e.alive, isTrue);
  });

  test('a shield absorbs exactly one hit', () {
    final e = _emptyEngine();
    e.shield = true;
    e.world.obstacles.add(Obstacle(1, ObstacleKind.block, 5));
    _run(e, 0.6);
    expect(e.alive, isTrue);
    expect(e.shield, isFalse);
    expect(e.takeEvents(), contains(GameEvent.shieldBreak));
  });

  test('coins are collected and counted', () {
    final e = _emptyEngine();
    e.world.coins.add(Coin(0, 0.5, 4));
    _run(e, 0.6);
    expect(e.coins, 1);
  });

  test('a long random run never throws and keeps values finite', () {
    for (var seed = 0; seed < 5; seed++) {
      final rng = math.Random(seed);
      final e = GameEngine(random: math.Random(seed));
      for (var i = 0; i < 60 * 90 && e.alive; i++) {
        final r = rng.nextInt(40);
        if (r == 0) e.moveLeft();
        if (r == 1) e.moveRight();
        if (r == 2) e.jump();
        if (r == 3) e.slide();
        e.update(1 / 60);
        e.takeEvents();
        expect(e.y.isFinite, isTrue);
        expect(e.score.isFinite, isTrue);
      }
    }
  });

  test('speed ramps up but never beyond the maximum', () {
    final e = _emptyEngine();
    expect(e.speed, GameEngine.startSpeed);
    e.time = 10000;
    expect(e.speed, GameEngine.maxSpeed);
  });
}
